/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized. This 
* software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING 
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT 
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE 
* AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR 
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE 
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software 
* and to discontinue the availability of this software.  By using this software, 
* you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2011, 2013 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : main.c
* Version      : 1.0.0
* Device(s)    : R5F104PJ
* Tool-Chain   : CA78K0R
* Description  : This file implements main function.
* Creation Date: 09-Sep-15
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#pragma interrupt INTIT r_it_interrupt
#include "r_macro.h"
#include "r_spi_if.h"
#include "lcd.h"
#include "uart.h"
#include "sw.h"
#include "adc.h"
#include "led.h"
#include "api.h"
#include <string.h>
#include "stdio.h"
#include "sw.h"
#include "check_switch.h"
//#define NO_ERROR	  10U
/***********************************************************************************************************************
Funtion declaration
***********************************************************************************************************************/
void LCD_Reset(void);
/**********************************************************************888
extern variable declare
******************************************************************/

volatile int G_elapsedTime = 0; 
extern float final_volt;
extern unsigned char LCD_Line;
extern int numb;
extern char temp_receive[UART_RX_BUFFER_LEN];
extern unsigned int check;
extern unsigned int enable_switch;
//int error_flag =NO_ERROR;
int index=0;
int lcd_status;
int time_flag ;
uint16_t gADC_Result;
float cur_volt ;
int adc_value;
float final_volt;
float _volt_temp;
char tx_buff_analog[13]= "$1991,A0000^";
char tx_buff_led[13] = "$1991,L0000^";
uint16_t stt;
extern int error_flag;
char* data;
/***********************************************************************************************************************
* Function Name: main
* Description  : This function implements main function.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void main(void){
    /* Initialize UART1 communication */
    Uart_Init();
  
      /* Initialize timer */
    R_IT_Create();
  
    /* Initialize ADC module */
    ADC_Create();
    ADC_Set_OperationOn();
    
    /* Enable interrupt */
    EI();
    
    /* Initialize SPI channel used for LCD */
    R_SPI_Init(SPI_LCD_CHANNEL);
	
    /* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
    R_SPI_SslInit(
    		SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
    		(unsigned char *)&P14,   /* Select Port register */
    		(unsigned char *)&PM14,  /* Select Port mode register */
    		5,                       /* Select pin index in the port */
   		0,                       /* Configure CS pin active state, 0 means active LOW level  */
    		0                        /* Configure CS pin active mode, 0 means active per transfer */
    );
    
    /*Reset LCD*/
    LCD_Reset();
          
    /* Start UART1 communication */
    Uart_Start();
    
    /* Start an A/D conversion */
    ADC_Start(); 
    
    /* Initialize LCD driver */
    InitialiseLCD();
    
    /* Clear LCD display */
    ClearLCD();

    /*LED_init*/
    init_led();
    
    /* Enable timer */
    R_IT_Start();
    intp_init();
    while (1U){   
//	 if(((SSR03&0x04)==0x04)||(SSR03&0x02)==0x02){
//		DisplayLCD(LCD_LINE8,(uint8_t *)"UART Err");
//		P1_bit.no0=1;
//	}
	    /*Check timer after 200ms*/
	  if (time_flag ==1){
		  time_flag =0;
	   	 /*Start UART */
	   	 Uart_Start();
		 
		 // LEDs
		stt=status_led();
		
		 sprintf(tx_buff_led,"$1991,L%.4x^",stt);
		 Uart_Transmit(tx_buff_led,13);
		 
	    	// ADC
	   	gADC_Result=get_ADC();
		cur_volt = (gADC_Result*FULL_RANGE_SCALE)/MAX_LEVEL_ADC;
		_volt_temp = final_volt; 
		if (((cur_volt - _volt_temp)>OVERALL_ERROR) || ((_volt_temp - cur_volt)>OVERALL_ERROR)){
			_volt_temp = cur_volt;

		}
		final_volt = _volt_temp;
		adc_value = (int)(((final_volt)*999)/3.3);
		sprintf(tx_buff_analog,"$1991,A%.3d^",adc_value);
		Uart_Transmit(tx_buff_analog,13);
		if(status == UART_RECEIVE_DONE){
			status = 0;
			check_receive_buff();
			//Uart_Transmit(rx_buff,13);
		}
		
	  } 
			
    	}
}

void LCD_Reset(void)
{
    int i =0;
    /* Output a logic LOW level to external reset pin*/
    P13_bit.no0 = 0;
    for (i = 0; i < 1000; i++){
        NOP();
    }

    /* Generate a raising edge by ouput HIGH logic level to external reset pin */
    P13_bit.no0 = 1;
    for (i = 0; i < 1000; i++){
        NOP();
    }

    /* Output a logic LOW level to external reset pin, the reset is completed */
    P13_bit.no0 = 0;
}

__interrupt static void r_it_interrupt(void){
	if (G_elapsedTime >=20){
		time_flag=1;
		G_elapsedTime=0;
	}
	G_elapsedTime++;
}
/******************************************************************************
End of file
******************************************************************************/
