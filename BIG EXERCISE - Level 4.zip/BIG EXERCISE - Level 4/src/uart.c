/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized. This 
* software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING 
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT 
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE 
* AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR 
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE 
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software 
* and to discontinue the availability of this software.  By using this software, 
* you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2011, 2013 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : uart.c
* Version      : Initial version 1.0.0
* Device(s)    : R5F104PJ
* Tool-Chain   : CA78K0R
* Description  : This file implements device driver for UART module.
* Creation Date: 09-Sep-15
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
#pragma interrupt INTSR1 UartRx_isr
#pragma interrupt INTSRE1 UartRx_error

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_macro.h"
#include "uart.h"
#include "led.h"
#include "lcd.h"
#include "stdlib.h"
#include <string.h>
#include <stdio.h>
//#define NO_ERROR	  10U
/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
char temp_receive[UART_RX_BUFFER_LEN];
unsigned char LCD_Line;
int error_flag;
extern int index;
extern int lcd_status;
char rx_buff[UART_RX_BUFFER_LEN];
char receive_data[9][UART_RX_BUFFER_LEN];
char* rx_buffer_ptr = &(rx_buff[0]);
unsigned int rx_Len;
unsigned char status = 0;
char cmd = 0;
int numb =0;
unsigned int rx_count = 0;
uint16_t LEDs_status = 0x0000;
/***********************************************************************************************************************
* Function Name: Uart_Init
* Description  : This function initializes the UART1.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void Uart_Init(void)
{
    /* Uart init UART0 */
    SAU0EN = 1U;   /*serial array unit 0 Enable*/
    NOP();
    NOP();
    NOP();
    NOP();
    SPS0 = 0x0004|0x0040; /*select clock for SAU*/
   
    ST0 = 0x04;      /* stop all channel */
    STMK1 = 1U;      /* disable INTST0 interrupt */
    STIF1 = 0U;      /* clear INTST0 interrupt flag */
    SRMK1 = 1U;      /* disable INTSR0 interrupt */
    SRIF1 = 0U;      /* clear INTSR0 interrupt flag */
    SREMK1 = 1U;     /* disable INTSRE0 interrupt */
    SREIF1 = 0U;     /* clear INTSRE0 interrupt flag */
    
    /* Set INTST0 high priority */
    STPR11 = 0U;
    STPR01 = 0U;
    /* Set INTSR0 high priority */
    SRPR11 = 0U;
    SRPR01 = 0U;
    
    SMR02 = 0x0022;   /* UART mode, empty buffer interrupt*/
    SCR02 = 0x8397;   /*Transmit mode, mask error interrupt, no parity, MSB first, stop bit 1 bit, data length 8 bit*/
    SDR02 = 0x3400U;  /*set clock transfer*/
    NFEN0 = 0x04;     /*noise enable for RXD0*/
    
    SIR03 = 0x07;     /*clear flag trigger */
    SMR03 = 0x0122;
    SCR03 = 0x4397;  /*Transmit mode, mask error interrupt, no parity, MSB first, stop bit 1 bit, data length 8 bit*/
    SDR03 = 0x3400;   /*set clock transfer*/
    
    SO0 |= 0x04;     /* output level normal */
    SOL0 |= 0x00;    /* output level normal */
    SOE0 |= 0x04;    /* enable UART1 output */
    
    /* Port inint for UART communicate */
    PMC0 &= 0xF7U;
    PM0 |= 0x08U;
    /* Set TxD1 pin */
    PMC0 &= 0xFBU;
    P0 |= 0x04U;
    PM0 &= 0xFBU;
}

/***********************************************************************************************************************
* Function Name: Uart_Start
* Description  : This function start UART1 operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void Uart_Start(void)
{
    SO0 |= 0x04;     /* output level normal */
    SOE0 |= 0x04;    /* enable UART0 output */
    SS0 |= 0x04|0x08;     /* enable UART0 receive and transmit */
    
    STIF1 = 0U;    /* clear INTST0 interrupt flag */
    SRIF1 = 0U;    /* clear INTSR0 interrupt flag */
    STMK1 = 1U;    /* disable INTST0 interrupt */
    SRMK1 = 0U;    /* enable INTSR0 interrupt */
    SREIF1 = 0U;
    SREMK1=1U;
    SREMK1=0U;
}

/***********************************************************************************************************************
* Function Name: Uart_Stop
* Description  : This function stop UART1 operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void Uart_Stop(void)
{
    STMK1 = 1U;    /* disable INTST0 interrupt */
    SRMK1 = 1U;    /* disable INTSR0 interrupt */
    
    ST0 |= 0x04;     /* enable UART0 receive and transmit */
    SOE0 &= ~0x04;    /* enable UART0 output */
    
    STIF1 = 0U;    /* clear INTST0 interrupt flag */
    SRIF1 = 0U;    /* clear INTSR0 interrupt flag */
}

/***********************************************************************************************************************
* Function Name: Uart_Transmit
* Description  : This function transmit number of data bytes, using UART.
* Arguments    : Transmission data pointer, data length.
* Return Value : None
***********************************************************************************************************************/
void Uart_Transmit(const char* tx_ptr, int Len)
{
  unsigned int LuiCount = 0;
  unsigned int LuiTimeOut = 0;
  
  for(LuiCount = 0; LuiCount < Len; LuiCount++)
  {
    TXD1 = *(tx_ptr + LuiCount);
    LuiTimeOut = UART_TIMEOUT;
    while((STIF1 == 0)||(LuiTimeOut--));
    STIF1 = 0;
  }
}

/***********************************************************************************************************************
* Function Name: Uart_ClearRxBuff
* Description  : This function clear Rx buffer of UART
* Arguments    : Buffer pointer, buffer length.
* Return Value : None
***********************************************************************************************************************/
void Uart_ClearBuff(char* buff_ptr, unsigned int Len)
{
  unsigned int LuiCount = 0;
  for(LuiCount = 0; LuiCount < Len; LuiCount ++)
  {
    *(buff_ptr + LuiCount) = '\0';
  }
 
}

/***********************************************************************************************************************
* Function Name: UartRx_isr
* Description  : This interrupt service routine of UART1
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
__interrupt void UartRx_isr(void)
{
	static unsigned int count = 0;
  
  /* Check for special character */
 	 if('$' == RXD1){
    		cmd = UART_CLEAR;
    		rx_count = 0;
    		count = 0;
    		status = 0;
 	 }
 	 else {
   		 *(rx_buffer_ptr + count) = RXD1;
   		 rx_count++;
    		 count++;
    		if(count > (UART_RX_BUFFER_LEN-2)){
      			count = 0;
    		}
    		else{
      			/* Do no thing */
    		}
		if('^' == RXD1){
			status = UART_RECEIVE_DONE;
			rx_count=0;
			count=0;
		}
		
 	 }
  
}

/***********************************************************************************************************************
* Function Name: check_receive_buff
* Description  : This function check data receive control led or display text
* Arguments    : char* buff
* Return Value : None
***********************************************************************************************************************/

void check_receive_buff(void){
unsigned int len = 1;
uint8_t i;
uint8_t j;
uint16_t led;
uint8_t line;
char temp[18];

	for(i=0;rx_buff[i]!='^'&& i<=30;i++){
		len++;
	}
	
	if(rx_buff[0]=='L'){
		
		if(len==6){
			led= (uint16_t)(rx_buff[2]-48)*10 + (uint16_t)(rx_buff[3]-48);
		}
		if(len==5) {
			led=(uint16_t)(rx_buff[2]-48);
		}
		control_LED(led);
		
	}
	else if(rx_buff[0]=='T'){
		
		if(len<=23){
			
			line= (uint8_t)(rx_buff[2]-48);
			for(j=0;j<=14;j++){
				temp[j]=' ';
			}
			for(j=3; rx_buff[j]!='^';j++){
				temp[j]=rx_buff[j];
			}
			temp[14]='\0';
			DisplayLCD(LCD_LINE1 + (line-1)*8,&temp[4]);
		}
		else {
			DisplayLCD(LCD_LINE1 + (line-1)*8, "Msg Err");
			P1_bit.no0 = 1;		
		}
		
	}
}

__interrupt void UartRx_error(void){
	if(((SSR03&0x04)==0x04)||(SSR03&0x02)==0x02){
		DisplayLCD(LCD_LINE8,(uint8_t *)"UART Err");
	}
	P1_bit.no0=1;
	SIR03=0x07;
}

int checkValidCharacter(char c){
	if('0' <= c && c <= '9'|| 'a' <= c && c <= 'z' || 'A' <= c && c <= 'Z' || c == ' ' || c == '_')
		return 1;		
	else
		return 0;		
}


/******************************************************************************
End of file
******************************************************************************/
