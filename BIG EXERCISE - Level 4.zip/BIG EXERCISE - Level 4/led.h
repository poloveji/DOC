#ifndef __LED_PORT
#define __LED_PORT

#define PORT6 (volatile unsigned char *)0xFFF06
#define PORT4 (volatile unsigned char *)0xFFF04
#define PORT10 (volatile unsigned char *)0xFFF0A
#define PORT15 (volatile unsigned char *)0xFFF0F

#endif
/*define value of led*/
#define LED3_ON 	0xFB
#define LED5_ON 	0xF5
#define LED7_ON 	0xEF
#define LED9_ON 	0xDF
#define LED11_ON 	0xBF
#define LED13_ON	0x7F

#define LED15_ON 	0xFD
#define LED4_ON 	0xFB
#define LED6_ON 	0xF7
#define LED8_ON 	0xEF
#define LED10_ON 	0xDF
#define LED12_ON	0xFB
#define LED14_ON 	0xFD

#define LED3_OFF 	0x04
#define LED5_OFF	0x08
#define LED7_OFF 	0x10
#define LED9_OFF	0x20
#define LED11_OFF 	0x40
#define LED13_OFF	0x80

#define LED15_OFF 	0x02
#define LED4_OFF 	0x04
#define LED6_OFF	0x08
#define LED8_OFF 	0x10
#define LED10_OFF 	0x20
#define LED12_OFF	0x04
#define LED14_OFF	0x02


extern unsigned char *PORT[13];	     
extern unsigned char led_on[13];	
extern unsigned char led_off[13];
extern uint16_t status_led(void);
//extern led_status led_status_1; 
void init_led(void);
uint16_t status_led(void);
void control_LED();
void Turn_Off_LED();

