#include "r_macro.h" 
#define sw3	(0x50)
#define pressed (P7&0x70)
unsigned int getswitch();
void delay();