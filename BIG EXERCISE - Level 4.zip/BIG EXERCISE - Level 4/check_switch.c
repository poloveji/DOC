#include "check_switch.h"    /* Standard IO library: sprintf */

unsigned int j, k;
unsigned int check;
unsigned int enable_switch;

/*Check switch*/
unsigned int getswitch(){
	check = pressed;
//	switch(check){
//		case sw3:
//			if(enable_switch == 1){
//				delay();
//				enable_switch = 0;
//				check = sw3;
//			}else {
//				check = 0;
//			}
//			break;
//			
//		default:
//			delay();
//			enable_switch = 1;
//			check = 0;
//			break;
//	}

	return check;
}

/*Delay function*/
void delay(){
	for (j = 0; j < 300; j++){
		for (k = 0; k < 2000; k++){
			if(pressed != 0x07){
				break;
			}
		}
	}
}