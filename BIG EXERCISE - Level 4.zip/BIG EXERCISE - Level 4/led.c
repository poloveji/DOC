#include "r_macro.h"
#include "led.h"
#include "math.h"
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include "stdio.h"
#include "uart.h"
#include "stdlib.h"
#define OFFSET_LEDNUMB	3
//#define NO_ERROR	  10U
unsigned char *PORT[13] ={PORT6,PORT4,PORT6,PORT4,PORT6,PORT4,PORT6,PORT4,PORT6,PORT15,PORT6,PORT10,PORT4};
unsigned char led_on[13] ={LED3_ON,LED4_ON,LED5_ON,LED6_ON,LED7_ON,LED8_ON,LED9_ON,LED10_ON,LED11_ON,LED12_ON,LED13_ON,LED14_ON,LED15_ON};
unsigned char led_off[13]={LED3_OFF,LED4_OFF,LED5_OFF,LED6_OFF,LED7_OFF,LED8_OFF,LED9_OFF,LED10_OFF,LED11_OFF,LED12_OFF,LED13_OFF,LED14_OFF,LED15_OFF};

//led_status led_status_1;
extern int error_flag;
extern numb;

/*Initialize Leds function*/
void init_led(){
	ADPC =1;
	PM4 &=0xC1;
	PM6 &=0x03;
	PM15 &=0xfb;
	PM10 &=0xfd;
	P6 =0xff;
	P4 =0xff;
	P15 =0xff;
	P10 =0xff;
	PM1_bit.no0 = 0;
//	PM4 &= ~0x3c;
//	PM6 &= ~0xfc;	// reduce warning W0401: Conversion may lose significant digits
//	PM10 &= ~0x02;
//	PM15 &= ~0x04;
//	PM1_bit.no0 = 0;	// LED2 on-board
//	PM4_bit.no1 = 0;	// LED15 on-board
//	ADPC = 1;	// P15.2 digital mode
	// Turn off all LEDs
	Turn_Off_LED();
}

/*assign led status value*/
uint16_t status_led(void){
	uint16_t stt= 0x0000;
	stt |= P6_bit.no2 == 0? 0x0001 : 0x0000; //LED3
	stt |= P4_bit.no2 == 0? 0x0002 : 0x0000; //LED4
	stt |= P6_bit.no3 == 0? 0x0004 : 0x0000; //LED5
	stt |= P4_bit.no3 == 0? 0x0008 : 0x0000; //LED6
	
	stt |= P6_bit.no4 == 0? 0x0010 : 0x0000; //LED7
	stt |= P4_bit.no4 == 0? 0x0020 : 0x0000; //LED8
	stt |= P6_bit.no5 == 0? 0x0040 : 0x0000; //LED9
	stt |= P4_bit.no5 == 0? 0x0080 : 0x0000; //LED10
	
	stt |= P6_bit.no6 == 0? 0x0100 : 0x0000; //LED11
	stt |= P15_bit.no2 == 0? 0x0200 : 0x0000; //LED12
	stt |= P6_bit.no7 == 0? 0x0400 : 0x0000; //LED13
	stt |= P10_bit.no1 == 0? 0x0800 : 0x0000; //LED14
	
	stt |= P4_bit.no1 == 0? 0x1000 : 0x0000; //LED15
	return stt;
}
/*control LEDs*/
void control_LED(uint16_t stt){
	stt=~stt;
	P6_bit.no2 =(stt & 0x0001); //LED3
	P4_bit.no2 =(stt & 0x0002)>>1; //LED4
	P6_bit.no3 =(stt & 0x0004)>>2; //LED5
	P4_bit.no3 =(stt & 0x0008)>>3; //LED6
	
	P6_bit.no4 =(stt & 0x0010)>>4; //LED7
	P4_bit.no4 =(stt & 0x0020)>>5; //LED8
	P6_bit.no5 =(stt & 0x0040)>>6; //LED9
	P4_bit.no5 =(stt & 0x0080)>>7; //LED10
	
	P6_bit.no6 =(stt & 0x0100)>>8; //LED11
	P15_bit.no2 =(stt & 0x0200)>>9; //LED12
	P6_bit.no7 =(stt & 0x0400)>>10; //LED13
	P10_bit.no1 =(stt & 0x0800)>>11; //LED14
	
	P4_bit.no1 =(stt & 0x1000)>>12; //LED15
}
void Turn_Off_LED(){
	P4 |= 0x3c;
	P6 |= 0xfc;
	P10 |= 0x02;
	P15 |= 0x04;

	P4_bit.no1 = 1;		// LED15 on-board
		
	P1_bit.no0 = 0;		// LED2 on-board
}