/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : main.c
* Version      : 1.0.0
* Device(s)    : R5F104PJ
* Tool-Chain   : CA78K0R
* Description  : This file implements for main function.
* Creation Date: 11-Sep-15
******************************************************************************/
/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#define WAITTIME 10

#define ERROR 1.2
#define MAXVOLT 3.3
#define RES 1023

#define LV0 0.00
#define LV1 0.15
#define LV2 0.28
#define LV3 0.55
#define LV4 0.83
#define LV5 1.11
#define LV6 1.37
#define LV7 1.65
#define LV8 1.93
#define LV9 2.21
#define LV10 2.48
#define LV11 2.75
#define LV12 3.03
#define LV13 3.30

/******************************************************************************
Includes 
******************************************************************************/
#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include "adc.h"      /* ADC driver interface */
#include "sw.h"       /* SW driver interface */
#include "api.h"      /* Timer */
#include "string.h"   /* sprintf */
#include <math.h>

/******************************************************************************
Private global variables and functions
******************************************************************************/
/* Declare a variable for A/D results */
volatile uint16_t gADC_Result = 0;
float Result1 = 0;
float Result2 = 0;
float Result3 = 0;
unsigned int Result4 = 0;
unsigned int Result5 = 0;
volatile int count = 0;   // Timer Counter
float prt = 0;



/* Global buffer array for storing the ADC
result integer to string conversion  */
static uint8_t lcd_buffer[] = "=H\'WXYZ ";

void LCD_Reset(void);
char string_shown_on_lcd[10];
void LCD_DisplayValue(void);
void LED_init(void);
void timer_init(void);

/******************************************************************************
* Function Name: main
* Description  : Main program
* Arguments    : none
* Return Value : none
******************************************************************************/
void main(void)
{
	/* Initialize external interrupt */
	INTC_Create();
	
	/* Initialize ADC module */
        ADC_Create();
	ADC_Set_OperationOn();
	
	/* Enable interrupt */
	EI();
	
	LCD_Reset();
	
	/* Initialize LEDs */
	LED_init();
	
	/*Setup and start timer*/
	timer_init();
	
	/* Initialize SPI channel used for LCD */
	R_SPI_Init(SPI_LCD_CHANNEL);
	
	/* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
	R_SPI_SslInit(
		SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
		(unsigned char *)&P14,   /* Select Port register */
		(unsigned char *)&PM14,  /* Select Port mode register */
		5,                       /* Select pin index in the port */
		0,                       /* Configure CS pin active state, 0 means active LOW level  */
		0                        /* Configure CS pin active mode, 0 means active per transfer */
	);
	/* Initialize LCD driver */
	InitialiseLCD();
	
	/* Clear LCD display */
	ClearLCD();
	
	/* Enable interrupt for switch */
	INTC10_Start();
	
	/* Display information on the debug LCD.*/
	DisplayLCD(LCD_LINE1, (uint8_t *)"VR1 voltage:");


	/* Start an A/D conversion */
	ADC_Start();

	
	/* Main loop - Infinite loop */
	/* Halt program in an infinite while loop */
	while (1U)
	{
		
		if (1 == ITIF)
		{
			count++;
			ITIF = 0;
		}
		if (WAITTIME == count)
		{
		/* Wait for the A/D conversion to complete */
		while(Adc_Status != ADC_DONE);

		/* Clear ADC flag */
		Adc_Status = 0;

		/* Shift the ADC result contained in the 16-bit ADCR register */
		gADC_Result = ADCR >> 6;
		Result1 = (float) gADC_Result;
		Result2 = (Result1*MAXVOLT)/RES;
		if (abs(Result2 - prt) > ((MAXVOLT*ERROR)/RES))
		{
			prt = Result2;
		}
		Result3 = prt*100;
		Result4 = ( int)Result3;
		Result5 = Result4/100;
		
		LCD_DisplayValue();
		
		ITIF = 0;
		count = 0;
		}		
		
		if (prt >= LV0 && prt < LV1)
		{
			P6_bit.no2 = 1;
			P4_bit.no2 = 1;
			P6_bit.no3 = 1;	
			P4_bit.no3 = 1;
			P6_bit.no4 = 1;
			P4_bit.no4 = 1;
			P6_bit.no5 = 1;
			P4_bit.no5 = 1;
			P6_bit.no6 = 1;
			P15_bit.no2 = 1;
			P6_bit.no7 = 1;
			P10_bit.no1 = 1;
		}		
		
		else if (prt >= LV1 && prt < LV2)
		{
			P6_bit.no2 = 0;
			P4_bit.no2 = 1;
			P6_bit.no3 = 1;	
			P4_bit.no3 = 1;
			P6_bit.no4 = 1;
			P4_bit.no4 = 1;
			P6_bit.no5 = 1;
			P4_bit.no5 = 1;
			P6_bit.no6 = 1;
			P15_bit.no2 = 1;
			P6_bit.no7 = 1;
			P10_bit.no1 = 1;
		}
		else if (prt >= LV2 && prt < LV3)
		{
			P6_bit.no2 = 0;
			P4_bit.no2 = 0;
			P6_bit.no3 = 1;	
			P4_bit.no3 = 1;
			P6_bit.no4 = 1;
			P4_bit.no4 = 1;
			P6_bit.no5 = 1;
			P4_bit.no5 = 1;
			P6_bit.no6 = 1;
			P15_bit.no2 = 1;
			P6_bit.no7 = 1;
			P10_bit.no1 = 1;
		}
		else if (prt >= LV3 && prt < LV4)
		{
			P6_bit.no2 = 0;
			P4_bit.no2 = 0;
			P6_bit.no3 = 0;	
			P4_bit.no3 = 1;
			P6_bit.no4 = 1;
			P4_bit.no4 = 1;
			P6_bit.no5 = 1;
			P4_bit.no5 = 1;
			P6_bit.no6 = 1;
			P15_bit.no2 = 1;
			P6_bit.no7 = 1;
			P10_bit.no1 = 1;
		}
		else if (prt >= LV4 && prt < LV5)
		{
			P6_bit.no2 = 0;
			P4_bit.no2 = 0;
			P6_bit.no3 = 0;	
			P4_bit.no3 = 0;
			P6_bit.no4 = 1;
			P4_bit.no4 = 1;
			P6_bit.no5 = 1;
			P4_bit.no5 = 1;
			P6_bit.no6 = 1;
			P15_bit.no2 = 1;
			P6_bit.no7 = 1;
			P10_bit.no1 = 1;
		}
		else if (prt >= LV5 && prt < LV6)
		{
			P6_bit.no2 = 0;
			P4_bit.no2 = 0;
			P6_bit.no3 = 0;	
			P4_bit.no3 = 0;
			P6_bit.no4 = 0;
			P4_bit.no4 = 1;
			P6_bit.no5 = 1;
			P4_bit.no5 = 1;
			P6_bit.no6 = 1;
			P15_bit.no2 = 1;
			P6_bit.no7 = 1;
			P10_bit.no1 = 1;
		}
		else if (prt >= LV6 && prt < LV7)
		{
			P6_bit.no2 = 0;
			P4_bit.no2 = 0;
			P6_bit.no3 = 0;	
			P4_bit.no3 = 0;
			P6_bit.no4 = 0;
			P4_bit.no4 = 0;
			P6_bit.no5 = 1;
			P4_bit.no5 = 1;
			P6_bit.no6 = 1;
			P15_bit.no2 = 1;
			P6_bit.no7 = 1;
			P10_bit.no1 = 1;
		}
		else if (prt >= LV7 && prt < LV8)
		{
			P6_bit.no2 = 0;
			P4_bit.no2 = 0;
			P6_bit.no3 = 0;	
			P4_bit.no3 = 0;
			P6_bit.no4 = 0;
			P4_bit.no4 = 0;
			P6_bit.no5 = 0;
			P4_bit.no5 = 1;
			P6_bit.no6 = 1;
			P15_bit.no2 = 1;
			P6_bit.no7 = 1;
			P10_bit.no1 = 1;
		}
		else if (prt >= LV8 && prt < LV9)
		{
			P6_bit.no2 = 0;
			P4_bit.no2 = 0;
			P6_bit.no3 = 0;	
			P4_bit.no3 = 0;
			P6_bit.no4 = 0;
			P4_bit.no4 = 0;
			P6_bit.no5 = 0;
			P4_bit.no5 = 0;
			P6_bit.no6 = 1;
			P15_bit.no2 = 1;
			P6_bit.no7 = 1;
			P10_bit.no1 = 1;
		}
		else if (prt >= LV9 && prt < LV10)
		{
			P6_bit.no2 = 0;
			P4_bit.no2 = 0;
			P6_bit.no3 = 0;	
			P4_bit.no3 = 0;
			P6_bit.no4 = 0;
			P4_bit.no4 = 0;
			P6_bit.no5 = 0;
			P4_bit.no5 = 0;
			P6_bit.no6 = 0;
			P15_bit.no2 = 1;
			P6_bit.no7 = 1;
			P10_bit.no1 = 1;
		}	
		else if (prt >= LV10 && prt < LV11)
		{
			P6_bit.no2 = 0;
			P4_bit.no2 = 0;
			P6_bit.no3 = 0;	
			P4_bit.no3 = 0;
			P6_bit.no4 = 0;
			P4_bit.no4 = 0;
			P6_bit.no5 = 0;
			P4_bit.no5 = 0;
			P6_bit.no6 = 0;
			P15_bit.no2 = 0;
			P6_bit.no7 = 1;
			P10_bit.no1 = 1;
		}
		else if (prt >= LV11 && prt < LV12)
		{
			P6_bit.no2 = 0;
			P4_bit.no2 = 0;
			P6_bit.no3 = 0;	
			P4_bit.no3 = 0;
			P6_bit.no4 = 0;
			P4_bit.no4 = 0;
			P6_bit.no5 = 0;
			P4_bit.no5 = 0;
			P6_bit.no6 = 0;
			P15_bit.no2 = 0;
			P6_bit.no7 = 0;
			P10_bit.no1 = 1;
		}
		else if (prt >= LV12 && prt <= LV13)
		{
			P6_bit.no2 = 0;
			P4_bit.no2 = 0;
			P6_bit.no3 = 0;	
			P4_bit.no3 = 0;
			P6_bit.no4 = 0;
			P4_bit.no4 = 0;
			P6_bit.no5 = 0;
			P4_bit.no5 = 0;
			P6_bit.no6 = 0;
			P15_bit.no2 = 0;
			P6_bit.no7 = 0;
			P10_bit.no1 = 0;
		}
	}
}

void LCD_Reset(void)
{
    int i =0;
    /* Output a logic LOW level to external reset pin*/
    P13_bit.no0 = 0;
    for (i = 0; i < 1000; i++)
    {
        NOP();
    }

    /* Generate a raising edge by ouput HIGH logic level to external reset pin */
    P13_bit.no0 = 1;
    for (i = 0; i < 1000; i++)
    {
        NOP();
    }

    /* Output a logic LOW level to external reset pin, the reset is completed */
    P13_bit.no0 = 0;
}
/***********************************************************************************************************************
* Function Name: LCD_DisplayValue
* Description  : This function displays value of LCD.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void LCD_DisplayValue(void)
{
	string_shown_on_lcd[0] = (char)(Result5+48);
	string_shown_on_lcd[1] = ',';
	Result4 = Result4 - (Result5*100);
	Result5 = Result4/10;
	string_shown_on_lcd[2] = (char)(Result5+48);
	Result4 = Result4 - (Result5*10);
	string_shown_on_lcd[3] = (char)(Result4+48);
	string_shown_on_lcd[4] = 'V';
	/* Display the contents of the local string lcd_buffer */
	DisplayLCD(LCD_LINE7, string_shown_on_lcd);
}
/***********************************************************************************************************************
* Function Name: LED_init
* Description  : This function initialize LEDs.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void LED_init(void)
{
	/* Initialize LEDs */
	PM4 = 0x00;
	P4 = 0xFF; 
	PM6 = 0x00;
	P6 = 0xFF;
	PM10 = 0x00;
	P10 = 0xFF;
	PM15 = 0x00;
	P15 = 0xFF;
	ADPC = 0x0B; // P15.2 digital
}
/***********************************************************************************************************************
* Function Name: timer_init
* Description  : This function initialize timer.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void timer_init(void)
{
	R_IT_Create();
	R_IT_Start();
}
/******************************************************************************
End of file
******************************************************************************/

