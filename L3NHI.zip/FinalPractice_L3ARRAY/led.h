/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized. This 
* software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING 
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT 
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE 
* AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR 
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE 
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software 
* and to discontinue the availability of this software.  By using this software, 
* you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2011, 2013 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    :led.h
* Version      : 1.0.0
* Device(s)    : R5F104PJ
* Tool-Chain   : CA78K0R
* Description  : This file implements for swtich.
* Creation Date: 19-Apr-17
***********************************************************************************************************************/  

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#define PORT6 (volatile unsigned char *)0xFFF06
#define PORT4 (volatile unsigned char *)0xFFF04
#define PORT10 (volatile unsigned char *)0xFFF0A
#define PORT15 (volatile unsigned char *)0xFFF0F

// LED on
#define LED3_ON 0XFB
#define LED4_ON 0XFB
#define LED5_ON 0XF7 
#define LED6_ON 0XF7
#define LED7_ON 0XEF
#define LED8_ON 0XEF
#define LED9_ON 0XDF
#define LED10_ON 0XDF
#define LED11_ON 0XBF
#define LED12_ON 0xFB
#define LED13_ON 0x7F
#define LED14_ON 0xFD

// LED off
#define LED3_OFF 0X04
#define LED4_OFF 0X04
#define LED5_OFF 0X08
#define LED6_OFF 0X08
#define LED7_OFF 0X10
#define LED8_OFF 0X10
#define LED9_OFF 0X20
#define LED10_OFF 0X20
#define LED11_OFF 0X40
#define LED12_OFF 0x04
#define LED13_OFF 0x80
#define LED14_OFF 0x02

#define MAXRANGE 12

/***********************************************************************************************************************
Global variable
***********************************************************************************************************************/


/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
void check_vr(void);
void turn_led(void);

/******************************************************************************
End of file
******************************************************************************/
