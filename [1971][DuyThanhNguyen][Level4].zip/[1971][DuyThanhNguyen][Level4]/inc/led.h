/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized. This 
* software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING 
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT 
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE 
* AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR 
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE 
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software 
* and to discontinue the availability of this software.  By using this software, 
* you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2011, 2013 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    :led.h
* Version      : 1.0.0
* Device(s)    : R5F104PJ
* Tool-Chain   : CA78K0R
* Description  : This file implements for swtich.
* Creation Date: 19-Apr-17
***********************************************************************************************************************/  

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#define PORT_MODE1 *(volatile unsigned char *)0XFFF21
#define PORT_MODE4 *(volatile unsigned char *)0XFFF24
#define PORT_MODE6 *(volatile unsigned char *)0xFFF26
#define PORT_MODE10 *(volatile unsigned char *)0xFFF2A
#define PORT_MODE15 *(volatile unsigned char *)0xFFF2F

/* Definition of led ports */
#define PORT1 *(volatile unsigned char *)0xFFF01
#define PORT4 *(volatile unsigned char *)0xFFF04
#define PORT6 *(volatile unsigned char *)0xFFF06
#define PORT10 *(volatile unsigned char *)0xFFF0A
#define PORT15 *(volatile unsigned char *)0xFFF0F

#define LED_ON 0
#define LED_OFF 1
#define LED2_ON 1
#define LED2_OFF 0
/* Definition of leds */
#define LED2 P1_bit.no0
#define LED3 P6_bit.no2
#define LED4 P4_bit.no2
#define LED5 P6_bit.no3
#define LED6 P4_bit.no3
#define LED7 P6_bit.no4
#define LED8 P4_bit.no4
#define LED9 P6_bit.no5
#define LED10 P4_bit.no5
#define LED11 P6_bit.no6
#define LED12 P15_bit.no2
#define LED13 P6_bit.no7
#define LED14 P10_bit.no1
#define LED15 P4_bit.no1

#define MAXRANGE 13

/***********************************************************************************************************************
Global variable
***********************************************************************************************************************/


/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
void check_vr(void);
void turn_led(int led_pos, int led_status);
void send_led_status (void);
void check_led(char[]);
/******************************************************************************
End of file
******************************************************************************/
