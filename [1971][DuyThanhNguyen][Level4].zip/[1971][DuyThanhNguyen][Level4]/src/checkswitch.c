
#include "r_macro.h"
#include "checkswitch.h"
#include "ChatDel.h"
#include "uart.h"
#include "led.h"
#include "lcd.h"
#include "uart.h"
#define SWT3 0x20

unsigned int check;

unsigned int enable_switch;

extern unsigned int button;
extern unsigned int match;
extern unsigned int prev;
extern unsigned int read;
extern unsigned int final;
extern unsigned int prevfinal;
//extern char temp_receive[UART_RX_BUFFER_LEN];

void checkswitch (void);
/******************************************************************************
* Function Name: checkswitch
* Description  : check Switch and reduce chattering
* Arguments    : none
* Return Value : none
******************************************************************************/
void checkswitch (void)
{
    button = ChatDel();
    //A button is pressed;
    if((button != 0) && (button != 0x70))
    {
	// Reset   
        if (button == SWT3)
        {
		//if (error_flag != NO_ERROR)
		//{
			   /* reset button*/
			   button = 0;
			   /*clear LCD*/
			   ClearLCD();
			   /*Reset error_flag*/
			   error_flag = NO_ERROR;
			   reset = 0;
			   /*Turn off LED 2*/
			   LED2 = LED2_OFF;
			   /*Reset receiving data buffer */
			   Uart_ClearBuff(&rx_buff[0], UART_RX_BUFFER_LEN - 1);
			   /*Turn off all led*/
			   P6 = 0xff;
			   P4 = 0xff;
			   LED12 = 1;
			   LED14 = 1;
			   /*Reset register check error of uart_error*/
			   SIR03 = 0x07;
			   /*Allow going to wait state for re-checking error of uart_error*/
			   SS0 |= 0x08;
		//}
        }
    }
}
