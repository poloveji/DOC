/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "iodefine.h"
#include "ChatDel.h"

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/
extern unsigned int match;
extern unsigned int prev;
extern unsigned int read;
extern unsigned int final;
extern unsigned int prevfinal;
/******************************************************************************
Private global variables and functions
******************************************************************************/

/***********************************************************************************************************************
* Function Name: ChatDel
* Description  : Remove chattering.
* Arguments    : None
* Return Value : One bit equivalent to one switch.
***********************************************************************************************************************/
unsigned int ChatDel(void)
{
	prevfinal = final;
	read = (P7&0x70);
	if(read != prev)
	{
		prev = read;
		match = 0;
	}
	else
	{
		match++;
		if(match >= 1)
		{
			match = 0;
			final = read;
		}
	}
	return ((final ^ prevfinal)&((~final)&0x70));
}