/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized. This 
* software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING 
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT 
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE 
* AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR 
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE 
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software 
* and to discontinue the availability of this software.  By using this software, 
* you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2011, 2013 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : uart.c
* Version      : Initial version 1.0.0
* Device(s)    : R5F104PJ
* Tool-Chain   : CA78K0R
* Description  : This file implements device driver for UART module.
* Creation Date: 09-Sep-15
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
#pragma interrupt INTSR1 UartRx_isr
#pragma interrupt INTSRE1 Uart_error
/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_macro.h"
#include "uart.h"
#include "lcd.h"
#include "led.h"
#include "stdlib.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
char rx_buff[UART_RX_BUFFER_LEN];
char* rx_buffer_ptr = &(rx_buff[0]);
unsigned int rx_Len;
unsigned char status = 0;
char cmd = 0;
unsigned int rx_count = 0;
unsigned int g_reset_buff = 0;
extern int wait;
extern int timerflag;
/***********************************************************************************************************************
* Function Name: Uart_Init
* Description  : This function initializes the UART1.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void Uart_Init(void)
{
    /* Uart init UART0 */
    SAU0EN = 1U;   /*serial array unit 0 Enable*/
    NOP();
    NOP();
    NOP();
    NOP();
    SPS0 = 0x0004|0x0040; /*select clock for SAU :8MHz : fck/2^2*/
   
    ST0 = 0x04;      /* stop all channel */
    
    /* This is interrupts transmission*/
    STMK1 = 1U;      /* disable INTST0 interrupt */
    STIF1 = 0U;      /* clear INTST0 interrupt flag */
    /* This is use for interrupts reception*/
    SRMK1 = 1U;      /* disable INTSR0 interrupt */
    SRIF1 = 0U;      /* clear INTSR0 interrupt flag */
    /* This is use for UART error interrupts detection flag*/
    SREMK1 = 1U;     /* disable INTSRE0 interrupt */
    SREIF1 = 0U;     /* clear INTSRE0 interrupt flag */
    
    /* Set INTST0 low priority end tranmission */
    STPR11 = 1U;
    STPR01 = 1U;
    /* Set INTSR0 low priority detect error interrupts */
    SRPR11 = 1U;
    SRPR01 = 1U;
    
    // UART1 include chanel 2-3
    /*Setting chanel 2-3*/
    SMR02 = 0x0022;   /* UART mode, empty buffer interrupt*/
    SCR02 = 0x8797;   /*Transmit only, mask error interrupt, ODD parity, LSB first, stop bit 1 bit, data length 8 bit*/
    SDR02 = 0x3200U;  /*set clock transfer:(4M/(2*2^2))/38400=103 but bit9 = 0(obligate) so choose 102 => bit 15->9 + bit8 : 0x32 */
    NFEN0 = 0x04;     /*noise enable for RXD0*/
    
    SIR03 = 0x07;     /*clear flag trigger */
    SMR03 = 0x0122;   /*Bit 8 = 1: Selected trigger for UART reception*/
    SCR03 = 0x4797;   /*Recieve only, mask error interrupt, ODD parity, LSB first, stop bit 1 bit, data length 8 bit*/
    SDR03 = 0x3200;   /*set clock transfer:(4M/(2*2^2))/38400=103 but bit9 = 0(obligate) so choose 102 => bit 15->9 + bit8 : 0x32 */
    
    SO0 |= 0x04;     /* output level normal */
    SOL0 |= 0x00;    /* output level normal */
    SOE0 |= 0x04;    /* enable UART1 output */
    
    /* Port inint for UART communicate */
    PMC0 &= 0xF7U;
    PM0 |= 0x08U;
    /* Set TxD1 pin */
    PMC0 &= 0xFBU;
    P0 |= 0x04U;
    PM0 &= 0xFBU;
}
/***********************************************************************************************************************
* Function Name: Uart_Start
* Description  : This function start UART1 operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void Uart_Start(void)
{
    SO0 |= 0x04;     /* output level normal */
    SOE0 |= 0x04;    /* enable UART0 output */
    SS0 |= 0x04|0x08;     /* enable UART0 receive and transmit */
    
    STIF1 = 0U;    /* clear INTST1 interrupt flag */
    SRIF1 = 0U;    /* clear INTSR1 interrupt flag */
    SREIF1 = 0U;   /* clear INTSRE1 interrupt flag */
    STMK1 = 1U;    /* disable INTST1 interrupt */
    SRMK1 = 0U;    /* enable INTSR1 interrupt */
    SREMK1 = 0U;   /* enable INTSRE1 interrupt */
}

/***********************************************************************************************************************
* Function Name: Uart_Stop
* Description  : This function stop UART1 operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void Uart_Stop(void)
{
    STMK1 = 1U;    /* disable INTST0 interrupt */
    SRMK1 = 1U;    /* disable INTSR0 interrupt */
    
    ST0 |= 0x04;     /* enable UART0 receive and transmit */
    SOE0 &= ~0x04;    /* enable UART0 output */
    
    STIF1 = 0U;    /* clear INTST0 interrupt flag */
    SRIF1 = 0U;    /* clear INTSR0 interrupt flag */
}

/***********************************************************************************************************************
* Function Name: Uart_Transmit
* Description  : This function transmit number of data bytes, using UART.
* Arguments    : Transmission data pointer, data length.
* Return Value : None
***********************************************************************************************************************/
void Uart_Transmit(const char* tx_ptr, int Len)
{
  unsigned int LuiCount = 0;
  unsigned int LuiTimeOut = 0;
  
  for(LuiCount = 0; LuiCount < Len; LuiCount++)
  {
    TXD1 = *(tx_ptr + LuiCount);
    LuiTimeOut = UART_TIMEOUT;
    while((STIF1 == 0)||(LuiTimeOut--));
    STIF1 = 0;
  }
}

/***********************************************************************************************************************
* Function Name: Uart_ClearRxBuff
* Description  : This function clear Rx buffer of UART
* Arguments    : Buffer pointer, buffer length.
* Return Value : None
***********************************************************************************************************************/
void Uart_ClearBuff(char* buff_ptr, unsigned int Len)
{
  unsigned int LuiCount = 0;
  for(LuiCount = 0; LuiCount < Len; LuiCount ++)
  {
    *(buff_ptr + LuiCount) = ' ';
  }
}

/***********************************************************************************************************************
* Function Name: UartRx_isr
* Description  : This interrupt service routine of UART1
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
__interrupt void UartRx_isr(void)
{
	if (error_flag == NO_ERROR)
	{
			char temp;
		    temp = RXD1;
		    if(first_char == 1)
		    {
		                if(temp != '$')
		                {
					first_char = 0;
					error_flag = MSG_ERROR;
					
		                }
		               else
		               {
		                            first_char=0;
		                }
		    }
		    if(end_flag == 1)
		    {
		                if(temp != '$')
		                {
						end_flag = 0;
						error_flag = MSG_ERROR;
					 
		                }
		                else if(temp == '$')
		                {
		                            rx_buff[count] = temp;
		                            count++;
		                            end_flag = 0;
		                }
		                
		    }
		    else if(end_flag == 0)
		    {
		                if('^' == temp)
		                {
		                            end_flag = 1;
					    	wait = 0;
			    			timerflag = 1;
		                            rx_buff[count] = temp;
		                }
		                else
		                {
		                            rx_buff[count] = temp;
		                }
		                count++;
		    }
		    if (count >= UART_RX_BUFFER_LEN - 1)
		    {
			    count = 0;
			    error_flag = MSG_ERROR;
			
		    }
	}
	else
	{
		//display_msg_error();
		//display_uart_error();
		end_flag = 0;
	}
}
/***********************************************************************************************************************
* Function Name: Uart_error
* Description  : This interrupt find error when recieve data
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
__interrupt void Uart_error(void)
{
	      if(SSR03&0x0007)
	      {  
	                              // Check uart error
	                            if(SSR03&PARITY_MASK)
	                            {
					    error_flag = UART_ERROR;
	                                          
	                                          SIR03 = 0x07;     /*clear flag trigger */
	                            } 
	                            else if(SSR03&OVERRUN_MASK)
	                            {
					    error_flag = UART_ERROR;
	                                     
	                                          SIR03 = 0x07;     /*clear flag trigger */
	                            } 
	                            else if(SSR03&FRAMING_MASK)
	                            {
					    error_flag = UART_ERROR;
	                                        
	                                          SIR03 = 0x07;     /*clear flag trigger */
	                            } 
	      }
}
/***********************************************************************************************************************
* Function Name: uart_receive
* Description  : This function process receiving data
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void uart_receive(void)
{
	if(rx_buff[1] == 'L')
	{
		check_led(rx_buff);
	}
	else if(rx_buff[1] == 'T')
	{
		check_text(rx_buff);	
	}
	else
	{
		error_flag = MSG_ERROR;
		
	}
}

/***********************************************************************************************************************
* Function Name: check_text
* Description  : This function process receiving data
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void check_text(char buff[])
{
	int i,j,h,a;
	int done;
	int display_done;
	int line;
	int temp;
	int charcount;
	char display_buff[19];
	done = 0;
	display_done = 0;
	line = 0;
	charcount = 0;
	for (h=0; h <MAXLINE; h++)
	{
		display_buff[h] = '\0';
	}

		for(i=0; done != 1; i++)
		{
			if (error_flag == NO_ERROR)
			{
				if(buff[i] == '^')
				{
					j = 0;
					charcount = 0;
					DisplayLCD((line-1)*8, (uint8_t *)display_buff);
					for (h=0; h <MAXLINE; h++)
					{
						display_buff[h] = '\0';
					}
					if(buff[i+1] != '$')
					{
						done = 1;
					}
				}
				else if(buff[i] == '$')
				{
					display_done = 0;
					line = (buff[i+3] - '0');
					if (line <1 || line >8)
					{
						error_flag = MSG_ERROR;
						
					}
						for(j = i+5; buff[j] != '^'; j++)
						{
								if((buff[j]>='0'&&buff[j]<='9')||(buff[j]>='a'&&buff[j]<='z')||(buff[j]>='A'&&buff[j]<='Z')||buff[j]==' '||buff[j]=='_')
								{
									if (charcount < MAXLCD)
									{
										display_buff[j-i-5] = buff[j];
									}
									
									else
									{
										;
									}
									charcount++;
								}
								else
								{
									error_flag = MSG_ERROR;
									return;
						
								}


						}
						if (charcount > MAXLINE)
						{
							error_flag = MSG_ERROR;
							return;
						}

				}
				
			}
			else
			{
				done = 1;
			}


		}
		for(h=0; h<MAXLINE; h++)
		{
			display_buff[h] = '\0';	
		}
		done = 0;

			
}
/***********************************************************************************************************************
* Function Name: display_msg_error
* Description  : This function displays message error
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void display_msg_error(void)
{
	if (error_flag != UART_ERROR && reset == 0)
	{
		P1_bit.no0 = LED2_ON;
		reset = 1;
		error_flag = MSG_ERROR;
		ClearLCD();
		DisplayLCD(LCD_LINE8, (uint8_t *)MSG_ERR);
	}
}
/***********************************************************************************************************************
* Function Name: display_uart_error
* Description  : This function displays message error
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void display_uart_error(void)
{
	if (error_flag != MSG_ERROR && reset == 0)
	{
		P1_bit.no0 = LED2_ON;
		reset = 1;
		error_flag = UART_ERROR;
		ClearLCD();
		DisplayLCD(LCD_LINE8, (uint8_t *)UART_ERR);
	}
}
/******************************************************************************
End of file
******************************************************************************/
