#ifndef __TIMER_H
#define __TIMER_H

#include "r_macro.h"  /* System macro and standard type definition */

void TIMER_IT_Create(void);
void TIMER_IT_Start(void);
void TIMER_IT_Stop(void);


#endif