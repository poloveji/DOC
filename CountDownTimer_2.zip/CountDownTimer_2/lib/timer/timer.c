#include "timer.h"

void TIMER_IT_Create(void)
{
    RTCEN   = 1U;       /* supply timer clock      */
    ITMC    = 0x0000U;       /* disable timer operation */
    ITMK    = 1U;       /* disable timer interrupt */ // set up to 1
    ITIF    = 0U;       /* clear timer interrupt flag */

    ITPR1   = 1U; 	// uu tien
    ITPR0   = 1U;	// uu tien
    OSMC    = 0x10U;    /* Select clock source: Low-speed on-chip oscillator clock */
			// the oscillator = 15Khz
			// Example interrupt cycles when 001H or FFFH is specified for ITCMP11 to ITCMP0
			// 1/32 [kHz] � (149 + 1) = 10 [�s] // for 1000us = 1ms
    ITMC    = 0x0095U; /* Configure timer data register */ // for counting to meet 150 time to reach 10uS interrupt 1 time
}

//    ITPR1   = 1U; 	// uu tien
 //   ITPR0   = 1U;	// uu tien
void TIMER_IT_Start(void)
{
    ITMC    = ITMC | 0x8000U;  /* enable timer operation     */// xor it for keep starting
    ITIF    = 1U;       /* clear timer interrupt flag */
    ITMK    = 0x0000;       /* enable timer interrupt     */
}

void TIMER_IT_Stop(void)
{
    ITMK    = 1U;       /* disable timer interrupt    */
    ITIF    = 1U;       /* clear timer interrupt flag */
    ITMC    = ITMC & 0x0000;  /* disable timer operation    */ // set up to 0 
}

