/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized. This 
* software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING 
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT 
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE 
* AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR 
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE 
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software 
* and to discontinue the availability of this software.  By using this software, 
* you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2011, 2013 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : sw.h
* Version      : 1.0.0
* Device(s)    : R5F104PJ
* Tool-Chain   : CA78K0R
* Description  : This file implements for swtich.
* Creation Date: 11-Sep-15
***********************************************************************************************************************/

/******************************************************************************
Pragma directive
******************************************************************************/
#pragma interrupt INTP10 intc10_interrupt_Sw1 //SW1 Interrupt
#pragma interrupt INTP9 intc9_interrupt_Sw2 //SW2 Interrupt
#pragma interrupt INTP8 intc8_interrupt_Sw3 //SW3 Interrupt

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_macro.h"
#include "iodefine.h"
#include "iodefine_ext.h"
#include "sw.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Declare a variable for storing switch press statuses */

extern volatile int gSwitch2;

time_settingbyinterrupt INT_time;


/***********************************************************************************************************************
* Function Name: INTC_Create_Sw1
* Description  : This function initializes INTP module.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void INTC_Create_Sw1(void)
{
    PMK10 = 1U;    /* disable INTP10 operation */
    PIF10 = 0U;    /* clear INTP10 interrupt flag */
    /* Set INTP10 level 1 priority */
    PPR110 = 0U;
    PPR010 = 1U;
    EGN1 = 0x07U; // 0x07 for all 0111
    /* Set INTP10 pin */
    PM7 |= 0x40U;
}


/***********************************************************************************************************************
* Function Name: INTC10_Start_Sw1
* Description  : This function clears INTP10 interrupt flag and enables interrupt.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void INTC10_Start_Sw1(void)
{
    PIF10 = 0U;    /* clear INTP10 interrupt flag */
    PMK10 = 0U;    /* enable INTP10 interrupt */
}

/***********************************************************************************************************************
* Function Name: INTC10_Stop_Sw1
* Description  : This function disables INTP10 interrupt and clears interrupt flag.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void INTC10_Stop_Sw1(void)
{
    PMK10 = 1U;    /* disable INTP10 interrupt */
    PIF10 = 0U;    /* clear INTP10 interrupt flag */
}

/***********************************************************************************************************************
* Function Name: intc10_interrupt_Sw1
* Description  : This function is INTP10 interrupt service routine.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
__interrupt static void intc10_interrupt_Sw1(void)
{
    /* Set flag to indicate switch SW1 was pressed */
    
    /* Clear interrupt flag */
    PIF10 = 0;
}

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

/***********************************************************************************************************************
* Function Name: INTC_Create_Sw2
* Description  : This function initializes INTP module.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void INTC_Create_Sw2(void)
{
    PMK9 = 1U;    /* disable INTP9 operation */
    PIF9 = 0U;    /* clear INTP9 interrupt flag */
    /* Set INTP9 level 1 priority */
    PPR19 = 0U;
    PPR09 = 1U;
    EGN1 = 0x07U; //external interrupt falling edge enable registers
    /* Set INTP9 pin */
    PM7 |= 0x20U;
}


/***********************************************************************************************************************
* Function Name: INTC9_Start_Sw2
* Description  : This function clears INTP9 interrupt flag and enables interrupt.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void INTC9_Start_Sw2(void)
{
    PIF9 = 0U;    /* clear INTP9 interrupt flag */
    PMK9 = 0U;    /* enable INTP9 interrupt */
}

/***********************************************************************************************************************
* Function Name: INTC9_Stop
* Description  : This function disables INTP9 interrupt and clears interrupt flag.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void INTC9_Stop_Sw2(void)
{
    PMK9 = 1U;    /* disable INTP9 interrupt */
    PIF9 = 0U;    /* clear INTP9 interrupt flag */
}

/***********************************************************************************************************************
* Function Name: intc9_interrupt_Sw2
* Description  : This function is INTP9 interrupt service routine.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
__interrupt static void intc9_interrupt_Sw2(void)
{
    /* Set flag to indicate switch SW2 was pressed */
    //gSwitchFlag2 = '2';
        
    /* Clear interrupt flag */
    PIF9 = 0;
}


/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/


/***********************************************************************************************************************
* Function Name: INTC_Create_Sw3
* Description  : This function initializes INTP module.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void INTC_Create_Sw3(void)
{
    PMK8 = 1U;    /* disable INTP8 operation */
    PIF8 = 0U;    /* clear INTP8 interrupt flag */
    /* Set INTP8 level 1 priority */
    PPR18 = 0U;
    PPR08 = 1U;
    EGN1 = 0x07U;
    /* Set INTP8 pin */
    PM7 |= 0x10U;
}


/***********************************************************************************************************************
* Function Name: INTC8_Start_Sw3
* Description  : This function clears INTP8 interrupt flag and enables interrupt.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void INTC8_Start_Sw3(void)
{
    PIF8 = 0U;    /* clear INTP8 interrupt flag */
    PMK8 = 0U;    /* enable INTP8 interrupt */
}

/***********************************************************************************************************************
* Function Name: INTC8_Stop
* Description  : This function disables INTP8 interrupt and clears interrupt flag.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void INTC8_Stop_Sw3(void)
{
    PMK8 = 1U;    /* disable INTP8 interrupt */
    PIF8 = 0U;    /* clear INTP8 interrupt flag */
}

/***********************************************************************************************************************
* Function Name: intc8_interrupt_Sw3
* Description  : This function is INTP8 interrupt service routine.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
__interrupt static void intc8_interrupt_Sw3(void)
{
    /* Set flag to indicate switch SW3 was pressed */
    //	gSwitchFlag3 = '3';
	
    gSwitch2 = 0;

    /* Clear interrupt flag */
    PIF8 = 0;
}




/******************************************************************************
End of file
******************************************************************************/
