#ifndef _BUTTON_H
#define _BUTTON_H

#include "r_macro.h"  /* System macro and standard type definition */

//SW1
extern uint8_t preSW1 ;
extern uint8_t curSW1 ;
extern uint8_t flagSW1 ;
//SW2
extern uint8_t preSW2 ;
extern uint8_t curSW2 ;
extern uint8_t flagSW2 ;
//SW3
extern uint8_t preSW3 ;
extern uint8_t curSW3 ;
extern uint8_t flagSW3 ;

typedef struct _TIME_t
{
	int second;
	int minute;
	int hour;
}TIME_t;

extern TIME_t get_time;
extern TIME_t set_time;

extern volatile int gSwitch2 ;
extern volatile int gSwitch3 ;


void Button(void);

#endif