/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : main.c
* Version      : 1.00
* Device(s)    : 
* Tool-Chain   : 
* H/W Platform : 
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 03.07.2015 1.00    First Release
******************************************************************************/


/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#pragma sfr
#pragma interrupt INTIT r_it_interrupt
#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include "timer.h"
#include "button.h"
#include "sw.h"
#include <string.h>

/******************************************************************************
Typedef definitions
******************************************************************************/
volatile int G_elapsedTime = 0;   // Timer Counter
unsigned int second = 1;
unsigned int Tsecond = 10; 
unsigned int holdCounting = 0;
char * string_shown_on_lcd[10];

//SW1
uint8_t preSW1 = 1 ;
uint8_t curSW1 = 1 ;
uint8_t flagSW1 = 0;
//SW2
uint8_t preSW2 = 1;
uint8_t curSW2 = 1; 
uint8_t flagSW2 = 0;
//SW3
uint8_t preSW3 = 1;
uint8_t curSW3 = 1;
uint8_t flagSW3 = 0;

int volatile gSwitch2 = 0 ;
int volatile gSwitch3 = 0;


 TIME_t get_time;
 TIME_t set_time;


/******************************************************************************
Macro definitions
******************************************************************************/

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/

/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/


/******************************************************************************
Private global variables and functions
******************************************************************************/
void r_main_userinit(void);
void settingDelay(char , unsigned long  );
void displayLCD(void);
/******************************************************************************
* Function Name: main
* Description  : Main program
* Arguments    : none
* Return Value : none
******************************************************************************/
void main(void)
{
	/* Initialize external interrupt */
	INTC_Create_Sw1();
	INTC_Create_Sw2();
	INTC_Create_Sw3();
	
	/* Initialize user system */
	r_main_userinit();
	
	/* Clear LCD display */
	ClearLCD();
	
	/* Enable interrupt */
	EI();
	gSwitch2 = 1;
	TIMER_IT_Create();
	G_elapsedTime = 0;
	
	while ( 1U ) 
	{
	 INTC8_Start_Sw3();
	 
	if(holdCounting == 0)
	{
		DisplayLCD(LCD_LINE1+3, "Setting");
		//DisplayLCD(LCD_LINE5, "Counting0"); // for testing case
	}
	else if(holdCounting == 1)
	{
		DisplayLCD(LCD_LINE1+3, "Counting");
		gSwitch3 = 1;
		//DisplayLCD(LCD_LINE5, "Counting1"); // for testing case.
	}
	// Setting time to Time Couting.
	set_time.second = get_time.second;
	set_time.minute = get_time.minute;
	set_time.hour = get_time.hour;
	
	displayLCD();
	Button();
	
	while(gSwitch3 == 1) // SW3 for start button
	{	
		holdCounting = 1;
		Button();

		if( (set_time.minute ==0) && (set_time.hour == 0))
		{
			gSwitch3 = 0;
			holdCounting = 0;
		}
		else
		{	
			holdCounting = 1;
		}
		EI();
		INTC8_Start_Sw3();
		
		if(set_time.second < 0 ) {
		set_time.second = 0;
		}
		if(set_time.second > 0 )
		{
			set_time.second--;
		}
		if(set_time.second == 0)
		{
			if(set_time.minute == 0)
			{
				if(set_time.hour > 0)
				{
					set_time.hour--;
					set_time.minute = 60;
				}
				
			}
			if(set_time.minute > 0)
			{
				set_time.minute--;
				set_time.second = 15;
			}

		}
		settingDelay('a',1000);
		settingDelay('a',1000);
		settingDelay('a',1000);
		//settingDelay();
		//wait(1000,'a');		
		displayLCD();
		Button();
	}
	while(gSwitch3 == 2)
	{
		INTC_Create_Sw3();
		EI();
		INTC8_Start_Sw3();
		Button();		
		if( (set_time.hour ==0) && (set_time.minute ==0) )
		{
			DisplayLCD(LCD_LINE1+3, "Setting");
			holdCounting = 0;
		}
		else
		{	
			//Button();
			DisplayLCD(LCD_LINE1+3, "Pausing");
			holdCounting = 1;
			// cho nay khien nut bi reset vo dung
			get_time.second = set_time.second ;
			get_time.minute = set_time.minute ;
			get_time.hour = set_time.hour;
			
			if(gSwitch2 == 0)
		{
			//Button();
			get_time.second  = 0;
			get_time.minute = 0;
			get_time.hour = 0;
			
			set_time.second = 0;
			set_time.minute = 0;
			set_time.hour = 0;
			
			displayLCD();
			
			holdCounting = 0;
			
			if( (set_time.minute ==0) && (set_time.hour == 0))
			{
				gSwitch3 = 0;
				holdCounting = 0;
				gSwitch2 = 1;
			}
			
			settingDelay('a',1000); // delay for bouncing.
			settingDelay('a',1000); // delay for bouncing.
			settingDelay('a',1000); // delay for bouncing.
		}
		
		}
		
	}

	}
	TIMER_IT_Stop();
/*	
	while ( 1U) 
	{
		settingDelay();
		Tsecond --;
		sprintf(string_shown_on_lcd, "%ds Time out", Tsecond);
		DisplayLCD(LCD_LINE1, string_shown_on_lcd);	
	}
*/
	
	DisplayLCD(LCD_LINE1, "* EXPLODE *");
}


void displayLCD()
{
	//sprintf(string_shown_on_lcd, "%0.2d:%0.2d:%0.2d", set_time.hour, set_time.minute, set_time.second); // for 3 digit testing
	sprintf(string_shown_on_lcd, "%0.2d:%0.2d", set_time.hour, set_time.minute); // main screen 
	DisplayLCD(LCD_LINE2 , string_shown_on_lcd);

}
/******************************************************************************
* Function Name: settingDelay
* Description  : Delay by Timer for decreasing.
* Arguments    : none
* Return Value : none
******************************************************************************/

void settingDelay(char typeOfDelay, unsigned long M ) // M for delay time in Asembly Ex: 1000-milisecond
{

				
//		void wait(int M, char c)
//{
	int j;
	if (typeOfDelay == 'c')
	{
		TIMER_IT_Create();
		TIMER_IT_Start();
		while(second>0)
		{
			if (G_elapsedTime >= 10)
			{	Button();
				G_elapsedTime = 0;
				second = second - 1;
			}
			
		}
		second = 1;
	}
	else if (typeOfDelay == 'a')
	{
		TIMER_IT_Stop();
		for (j = 0; j < M/10; j++)
		{
			#asm
			push HL
			push AX
			
			movw AX, #07CFEH
			?L0:
				SUBW AX, #1
				NOP
				NOP
				NOP
				NOP
				NOP
			BNZ $?L0
			
			NOP
			NOP
			NOP
			NOP
			NOP
			NOP
			NOP
			NOP
			pop AX
			pop HL
			#endasm
		}
	}
	
//}
}
/******************************************************************************
* Function Name: r_main_userinit
* Description  : User initialization routine
* Arguments    : none
* Return Value : none
******************************************************************************/
void r_main_userinit(void)
{
	uint16_t i;

	/* Enable interrupt */
	EI();

	/* Output a logic LOW level to external reset pin*/
	P13_bit.no0 = 0;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Generate a raising edge by ouput HIGH logic level to external reset pin */
	P13_bit.no0 = 1;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Output a logic LOW level to external reset pin, the reset is completed */
	P13_bit.no0 = 0;
	
	/* Initialize SPI channel used for LCD */
	R_SPI_Init(SPI_LCD_CHANNEL);
	
	/* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
	R_SPI_SslInit(
		SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
		(unsigned char *)&P14,   /* Select Port register */
		(unsigned char *)&PM14,  /* Select Port mode register */
		5,                       /* Select pin index in the port */
		0,                       /* Configure CS pin active state, 0 means active LOW level  */
		0                        /* Configure CS pin active mode, 0 means active per transfer */
	);
	
	/* Initialize LCD driver */
	InitialiseLCD();	
}

__interrupt static void r_it_interrupt(void)
{
    /* Start user code. Do not edit comment generated here */
    G_elapsedTime++;
    /* End user code. Do not edit comment generated here */
}


/******************************************************************************
End of file
******************************************************************************/

