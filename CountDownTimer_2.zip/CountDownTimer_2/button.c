#include "button.h"

/******************************************************************************
* Function Name: button
* Description  : Pressed Button
* Arguments    : none
* Return Value : none
******************************************************************************/
void Button(void)
{
	//SW1*************************************************************
	if(P7_bit.no6 == 0)
	{
		curSW1++;
		preSW1 = 0;
	}
	if(P7_bit.no6 == 1)
	{
		if(preSW1 == 0 && curSW1 > 2)
		{
			flagSW1++;
			flagSW2 = 0;
			
			curSW1 = 0;
			preSW1 = 1;
			get_time.second++; // for setting second
			get_time.hour++;
			//printfString(LCD_LINE2, second, minute);
		}
		if(preSW1 == 0 && curSW1 <= 2)
		{
			curSW1 = 0;
			preSW1 = 1;
		}
	}
	
	//SW2*************************************************************
	if(P7_bit.no4 == 0)
		{
			curSW2++;
			preSW2 = 0;
		}
		if(P7_bit.no4 == 1)
		{
			if(preSW2 == 0 && curSW2 > 2)
			{
				flagSW2++;
				flagSW1 = 0;
				
				curSW2 = 0;
				preSW2 = 1;
				gSwitch2=0;
				
				get_time.minute++;// for setting minute
			//	printfString(LCD_LINE2, second, minute);
				if(flagSW3 == 2)
				{
					gSwitch2 = 0; // set press to reset 
					//second = 0;
					//minute = 0;
					//SW1
					preSW1 = 1;
					curSW1 = 1;
					flagSW1 = 0;
					//SW2
					preSW2 = 1;
					curSW2 = 1;
					flagSW2 = 0;
					//SW3
					preSW3 = 1;
					curSW3 = 1;
					flagSW3 = 0;
					//G_elapsedTime = 100;
				}	
				gSwitch2 = 1;
			}
			if(preSW2 == 0 && curSW2 <= 2)
			{
				curSW2 = 0;
				preSW2 = 1;
			}
		}
	//SW3*************************************************************
	if(P7_bit.no5 == 0)
		{
			curSW3++;
			preSW3 = 0;
		}
	if(P7_bit.no5 == 1)
		{
	if(preSW3 == 0 && curSW3 > 2)
			{
				gSwitch3++;
				if(gSwitch3 ==3)
				{
					gSwitch3 = 0;
				}
				
				
				flagSW3++;
				if(flagSW3 >3)
				{
					flagSW3 = 3;
				}
				/*
				if(flagSW3 ==2)
				{
					gSwitch3 = 1;
				}
				*/
				flagSW1 = 0;
				flagSW2 = 0;
				curSW3 = 0;
				preSW3 = 1;
			}
	if(preSW3 == 0 && curSW3 <= 2)
			{
				curSW3 = 0;
				preSW3 = 1;
			}
		}		
}