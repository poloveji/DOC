/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : main.c
* Version      : 1.0.0
* Device(s)    : R5F104PJ
* Tool-Chain   : CA78K0R
* Description  : This file implements for main function.
* Creation Date: 11-Sep-15
******************************************************************************/

/******************************************************************************
Includes 
******************************************************************************/
#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include "adc.h"      /* ADC driver interface */
#include "sw.h"       /* SW driver interface */
#include "api.h"      /* Timer */
#include "string.h"   /* sprintf */
#include <math.h>
#include "lcd.h"
#include <led.h>

/******************************************************************************
Private global variables and functions
******************************************************************************/
/* Declare a variable for A/D results */
volatile uint16_t gADC_Result = 0;
float res1=0;
float res2=0;
float res3=0;
unsigned int res4=0;
unsigned int res5=0;
float prev_res=0;
int count=0;
int pos=0;
char string_shown_on_lcd[10];
uint8_t *port[12] = {PORT6,PORT4,PORT6,PORT4,PORT6,PORT4,PORT6,PORT4,PORT6,PORT15,PORT6,PORT10};
uint8_t led_on[12] = {LED3_ON,LED4_ON,LED5_ON,LED6_ON,LED7_ON,LED8_ON,LED9_ON,LED10_ON,LED11_ON,LED12_ON,LED13_ON,LED14_ON};
uint8_t led_off[12] = {LED3_OFF,LED4_OFF,LED5_OFF,LED6_OFF,LED7_OFF,LED8_OFF,LED9_OFF,LED10_OFF,LED11_OFF,LED12_OFF,LED13_OFF,LED14_OFF};
float value[12]	 = {0.15,0.28,0.55,0.83,1.11,1.37,1.65,1.93,2.21,2.48,2.75,3.03};

/* Global buffer array for storing the ADC
result integer to string conversion  */
static uint8_t lcd_buffer[] = "=H\'WXYZ ";

void LCD_Reset(void);

/******************************************************************************
* Function Name: main
* Description  : Main program
* Arguments    : none
* Return Value : none
******************************************************************************/
void main(void)
{
	/* Initialize external interrupt */
	INTC_Create();
	
	/* Initialize ADC module */
        ADC_Create();
	ADC_Set_OperationOn();
	
	/* Enable interrupt */
	EI();
	
	LCD_Reset();
	
	/*Setup and start timer*/
	R_IT_Create();
	R_IT_Start();
	
	/* Initialize SPI channel used for LCD */
	R_SPI_Init(SPI_LCD_CHANNEL);
	
	/* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
	R_SPI_SslInit(
		SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
		(unsigned char *)&P14,   /* Select Port register */
		(unsigned char *)&PM14,  /* Select Port mode register */
		5,                       /* Select pin index in the port */
		0,                       /* Configure CS pin active state, 0 means active LOW level  */
		0                        /* Configure CS pin active mode, 0 means active per transfer */
	);
	
	/* Initialize LCD driver */
	InitialiseLCD();
	
	/* Clear LCD display */
	ClearLCD();
	
	/* Enable interrupt for switch */
	INTC10_Start();
	
	/*Initialize LEDs*/
	PM4=0x00;
	P4=0xFF;
	PM6=0x00;
	P6=0xFF;
	PM10=0x00;
	P10=0xFF;
	ADPC = 0x0B;
	P15=0xFF;
	PM15=0x00;
	/* Display information on the debug LCD.*/
	DisplayLCD(LCD_LINE1, (uint8_t *)"Volt of VR1 ");
	/*Start ADC*/
	ADC_Start();
	
	
	/* Main loop - Infinite loop */
	/* Halt program in an infinite while loop */
	while (1U)
	{
	    if (ITIF == 1){
		count++;
		ITIF=0;
	    }
	    
	    if(count==10){
		/* Wait for the A/D conversion to complete*/
		while(Adc_Status != ADC_DONE);
		/* Clear ADC flag*/
		Adc_Status = 0;

		/* Shift the ADC result contained in the 16-bit ADCR register */
		gADC_Result = ADCR >> 6;
		res1 = (float) gADC_Result;
		res2 = (res1*3.3)/1023;
		if (abs(res2 - prev_res) > ((1.2*3.3)/1023)){
			prev_res = res2;
		}
		res3 = prev_res*100;
		res4 = (int)res3;
		res5 = res4/100;
		string_shown_on_lcd[0] = (res5+48);
		string_shown_on_lcd[1] = ',';
		res4 = res4 - (res5*100);
		res5 = res4/10;
		string_shown_on_lcd[2] = (res5+48);
		res4 = res4 - (res5*10);
		string_shown_on_lcd[3] = (res4+48);
		string_shown_on_lcd[4] = 'V';
		
		/* Display the contents of the local string lcd_buffer */
		DisplayLCD(LCD_LINE3, string_shown_on_lcd);
		ITIF = 0;
		count = 0;
		check_vr();
		turn_led();
}
	}
}
void LCD_Reset(void)
{
    int i =0;
    /* Output a logic LOW level to external reset pin*/
    P13_bit.no0 = 0;
    for (i = 0; i < 1000; i++)
    {
        NOP();
    }

    /* Generate a raising edge by ouput HIGH logic level to external reset pin */
    P13_bit.no0 = 1;
    for (i = 0; i < 1000; i++)
    {
        NOP();
    }

    /* Output a logic LOW level to external reset pin, the reset is completed */
    P13_bit.no0 = 0;
}
/******************************************************************************
End of file
******************************************************************************/
