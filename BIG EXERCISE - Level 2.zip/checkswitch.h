#ifndef _checkswitch_h
#define _checkswitch_h
extern int ClearChattering();
extern void check_switch();
extern void check_sw12();
extern void Record();
extern void CountUp();
extern void Display(int min, int sec, int centisec);
extern void DisplayList();
extern int i;
extern int state; 
extern int current;
extern int prev; 
extern int prevoutput; 
extern int output;
extern int match_times;
extern int pressed; 
extern int G_elapsedTime; 
extern char * string_shown_on_lcd[10]; 
extern int rec_min[20];
extern int rec_sec[20];
extern int rec_centisec[20];
extern int a;
extern int j;
extern int k;
extern int time;
extern int ret;
extern unsigned char x;
extern int scroll;
extern int first_record;
extern int last_record;
extern int temp_sec;
extern int temp_centi;
extern int record_inc;
#endif