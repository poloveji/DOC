#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include <string.h>
#include "Glyph_API.h" 
#include "checkswitch.h"
#include "timer.h"
#define PAUSE 1 // define macro for PAUSE state.
#define RUN 2 // define macro for RUN state.
#define sw1 0x40 //define switch 1
#define sw2 0x10 //define switch 2
#define sw3 0x20 //define switch 3
#define sw12 0x50 //define switch 12
int i=0;
int j=0;
int y =1;
int state=PAUSE; //declare state variable
int current; //declare current variable
int min=0; //declare minute variable
int sec=0; //declare second variable
int centisec=0;
int prev=0x70; //declare previous variable
int prevoutput=0x70; //declare previous output variable
int output=0x70; //declare output variable
int match_times=0; //declare match times variable
int pressed=0; //declare pushed variable
int G_elapsedTime=0; //declare elapsed time variable
char * string_shown_on_lcd[10]; //declare string_shown_on_lcd
int rec_min[20];
int rec_sec[20];
int rec_centisec[20];
int ret=0;
int a=0;
extern int flag;
int scroll=0;
int first_record=0;
int last_record=0;
int temp_sec, temp_centi;
int record_inc=0;
int k=0;

/*Define Clear Chattering function*/
int ClearChattering(void){
prevoutput = output;
current = (P7&0x70);
	if(prev!=current){
		match_times=0;
		prev=current;
	}
	else{
		match_times=match_times+1;
		if(match_times>100){
			match_times=0;
			output=current;
			if (output == 0x20 && prevoutput != 0x20)
			{
				prevoutput = 0x70;
			}
		}
	}
return (output ^ prevoutput) & (~output);
}

/*Define check switch function*/
void check_switch(){
	pressed=ClearChattering(); 
	if(pressed==sw3){
		if(state==PAUSE){
			timer_start();
			state=RUN;
			DisplayLCD(LCD_LINE1, (uint8_t *)"RUNNING      ");
			ret=1;
		}
		else if(state==RUN){
			ret=2;
			
		}
	}
	
	if(pressed==sw2){
	//if(state==RUN){
			
			scroll++;
			if(scroll>=i-6){
				last_record=1;
				temp_sec=sec;
				temp_centi=centisec;
				if(state==PAUSE) timer_start();
				scroll=i-6;
			}
			if(scroll>14) scroll=14;
		//}
			ret=3;	
	}
	
	

	if(pressed==sw1){
		//if(state==RUN){
			scroll--;
			if(scroll<0){
				scroll=0;
				temp_sec=sec;
				temp_centi=centisec;
				first_record=1;
				if(state==PAUSE) timer_start();
			}
			ret=4;
		//}
	}

	if(pressed==sw12){
		if(state==RUN){
			state=PAUSE;
			ret=5;
		}
		else if(state==PAUSE){
			ret=6;
		}
	}
}

/*Define record function*/
void Record(){
	if(scroll==(i+record_inc-6)) scroll++;
	if(scroll>14) scroll=14;
	if(i<20){
		rec_min[i]=min;
		rec_sec[i]=sec;
		rec_centisec[i]=centisec;
		i++;
	}
	else if(i==20){
		int aa;
		for(aa=0;aa<20;aa++){
			rec_min[aa]=rec_min[aa+1];
			rec_sec[aa]=rec_sec[aa+1];
			rec_centisec[aa]=rec_centisec[aa+1];
		}
		record_inc++;
		rec_min[19]=min;
		rec_sec[19]=sec;
		rec_centisec[19]=centisec;
		if((scroll<i-6)&&(scroll>0)) scroll--; 
	}	
	
			
	
}
	



/*Define displaying minute, second & centisecond function*/
void Display(int min, int sec, int centisec){
	sprintf(string_shown_on_lcd," %d:%d:%d ", min, sec, centisec);
	DisplayLCD(LCD_LINE2,string_shown_on_lcd);
}

/*Define display record list function*/
void DisplayList()
{
		k=0;
		y=1;
		if(i<6){
			k=0;
		}
		else {
			k=scroll;
		}
		if(first_record==1){
			if(i==0 && rec_min[0]==0 && rec_sec[0]==0 && rec_centisec[0]==0){
				DisplayLCD(LCD_LINE1,(uint8_t *) "No record   ");
			}
			else {
				DisplayLCD(LCD_LINE1, (uint8_t *)"First Record"); 
			}
			first_record=0;
		}
		if(last_record==1){
			if(i==0 && rec_min[0]==0 && rec_sec[0]==0 && rec_centisec[0]==0){
				DisplayLCD(LCD_LINE1,(uint8_t *) "No record   ");
			}
			else {
				DisplayLCD(LCD_LINE1, (uint8_t *)"Last record ");
			}
			last_record=0;
		}
		else{
		for(j=k;j<k+6;j++){
			if((rec_min[j]!=0)||(rec_sec[j]!=0)||(rec_centisec[j]!=0)){
				sprintf(string_shown_on_lcd, "#%d %d:%d:%d  ",j+1+record_inc, rec_min[j], rec_sec[j], rec_centisec[j]);
				DisplayLCD( (LCD_LINE2 + y*8),(uint8_t*) string_shown_on_lcd);
				y++;	
			}
			ret=1;
		}
		}
	
}
