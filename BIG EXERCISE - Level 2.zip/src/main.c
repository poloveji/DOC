/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : main.c
* Version      : 1.00
* Device(s)    : 
* Tool-Chain   : 
* H/W Platform : 
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 01.07.2015 1.00    First Release
******************************************************************************/


/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include "timer.h"    /* Timer driver interface */
#include "stdio.h"    /* Standard IO library: sprintf */
#include "checkswitch.h"

/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions

******************************************************************************/
#define PAUSE 1 // define macro for setting state.
#define RUN 2 // define macro for counting state.
#define sw1 0x40 //define switch 1
#define sw2 0x10 //define switch 1
#define sw3 0x20 //define switch 1

int flag=0;
int b;

//char * string_shown_on_lcd[10];

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/

/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/

/******************************************************************************
Private global variables and functions
******************************************************************************/
void r_main_userinit(void);

/******************************************************************************
* Function Name: main
* Description  : Main program
* Arguments    : none
* Return Value : none
******************************************************************************/
void main(void)
{
	/* Local time structure to temporary store the global time */
	//time_t p_time;

	/* Initialize user system */
	r_main_userinit();
	
	/* Clear LCD display */
	ClearLCD();
	/*Display default setting state*/
	DisplayLCD(LCD_LINE1, (uint8_t *)"PAUSING      ");
	Display(min, sec, centisec);
	timer_init();
	
	/* Main loop - Infinite loop */
	
	while (1) 
	{	
		check_switch(); //check which switch is pressed
		/*Switch 3 is pressed and state is RUN*/
                if(ret==2) {
			Record();
			DisplayList();
		}
		/*Switch 1&2 are pressed and state is RUN*/
		if(ret==5){
			DisplayLCD(LCD_LINE1, (uint8_t *)"PAUSING     ");
			timer_stop();
			DisplayList();
		}
		/*Switch 1&2 are pressed and state is PAUSE*/
		if(ret==6){
			min=0;
			sec=0;
			centisec=0;
			Display(min, sec, centisec);
			ClearLCD();
			i=0;
			DisplayLCD(LCD_LINE1, (uint8_t *)"PAUSING     ");
			DisplayLCD(LCD_LINE2," 0:0:0 ");
			for(b=0;b<20;b++){
				rec_min[b]=0;
				rec_sec[b]=0;
				rec_centisec[b]=0;
			}
			record_inc=0;
			scroll=0;
			k=0;
			ret=0;
			timer_stop();
		}
		/*Switch 2 is pressed*/
		if(ret==3){
			DisplayList();
		}
		/*Switch 1 is pressed*/
		if(ret==4){
			DisplayList();
		}
		/*If state is RUN*/
		if(state==RUN){
			if(flag==1){
				Display(min, sec, centisec);
				if((sec==temp_sec+2)&&(centisec==temp_centi)){
					DisplayLCD(LCD_LINE1, (uint8_t *)"RUNNING      ");
				}
			flag=0;
			}		
		}
		/*If state is PAUSE*/
		if(state==PAUSE){
			if((sec==temp_sec+2)&&(centisec==temp_centi)){
				DisplayLCD(LCD_LINE1, (uint8_t *)"PAUSING      ");
				timer_stop();
				sec=temp_sec;
				sec=temp_centi;
			}
		}
		
				
	}
	
}


/******************************************************************************
* Function Name: r_main_userinit
* Description  : User initialization routine
* Arguments    : none
* Return Value : none
******************************************************************************/


void r_main_userinit(void)
{
	uint16_t i;

	/* Enable interrupt */
	EI();

	/* Output a logic LOW level to external reset pin*/
	P13_bit.no0 = 0;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Generate a raising edge by ouput HIGH logic level to external reset pin */
	P13_bit.no0 = 1;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Output a logic LOW level to external reset pin, the reset is completed */
	P13_bit.no0 = 0;
	
	/* Initialize SPI channel used for LCD */
	R_SPI_Init(SPI_LCD_CHANNEL);
	
	/* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
	R_SPI_SslInit(
		SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
		(unsigned char *)&P14,   /* Select Port register */
		(unsigned char *)&PM14,  /* Select Port mode register */
		5,                       /* Select pin index in the port */
		0,                       /* Configure CS pin active state, 0 means active LOW level  */
		0                        /* Configure CS pin active mode, 0 means active per transfer */
	);
	
	/* Initialize LCD driver */
	InitialiseLCD();	
}

/******************************************************************************
End of file
******************************************************************************/