/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#pragma interrupt INTIT r_it_interrupt
#include "api.h"
/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/
extern uint8_t snd_msg_flg;
/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/

/******************************************************************************
Private global variables and functions
******************************************************************************/
volatile int G_elapsedTime = 0;
/******************************************************************************
* Function Name: R_IT_Create
* Description  : 
* Arguments    : none
* Return Value : none
******************************************************************************/
void R_IT_Create(void)
{
    RTCEN   = 1U;       /* supply timer clock      */
    ITMC    = 0U;       /* disable timer operation */
    ITMK    = 1U;       /* disable timer interrupt */
    ITIF    = 0U;       /* clear timer interrupt flag */

    OSMC    = 0x10U;    /* Select clock source: Low-speed on-chip oscillator clock */

    //ITMC    = 1499U;    /* Configure timer data register (1499+1)/15kHz = 100ms = 10 centisecond */
    ITMC    = 149U; /* Configure timer data register 149, delay 10ms (149+1)/15000 = 10ms*/

}

/******************************************************************************
* Function Name: R_IT_Start
* Description  : 
* Arguments    : none
* Return Value : none
******************************************************************************/
void R_IT_Start(void)
{
    ITMC    = ITMC | 0x8000;  /* enable timer operation     */
    ITIF    = 0U;       /* clear timer interrupt flag */
    ITMK    = 0U;       /* enable timer interrupt     */
}

/******************************************************************************
* Function Name: R_IT_Stop
* Description  : 
* Arguments    : none
* Return Value : none
******************************************************************************/
void R_IT_Stop(void)
{
    ITMK    = 1U;       /* disable timer interrupt    */
    ITIF    = 0U;       /* clear timer interrupt flag */
    ITMC    = ITMC & 0x000FU;  /* disable timer operation    */
}

/******************************************************************************
* Function Name: r_it_interrupt
* Description  : Interrupt service routine for INTIT 
* Arguments    : none
* Return Value : none
******************************************************************************/
__interrupt static void r_it_interrupt(void)
{
	// Start user code. Do not edit comment generated here 
	G_elapsedTime++;
	if (G_elapsedTime >= 20)
	{
		snd_msg_flg = 1;
		G_elapsedTime = 0;	// 200ms	
	}
	// End user code. Do not edit comment generated here 
}