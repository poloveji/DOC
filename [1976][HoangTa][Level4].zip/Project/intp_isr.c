/******************************************************************************
Pragma directive
******************************************************************************/
#pragma interrupt INTP10 intp10_isr //SW1 Interrupt
#pragma interrupt INTP8 intp8_isr   //SW2 Interrupt
#pragma interrupt INTP9 intp9_isr   //SW3 Interrupt

/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#include "r_macro.h"  /* System macro and standard type definition */
#include "lcd.h"
#include "intp.h"
//#include "api.h"	/* 12-bit interval timer */
/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/
//#define COUNT 2
/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/

/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/
uint8_t SW1_flag;	// process SW1 in main
uint8_t SW2_flag;	// process SW2 in main
/******************************************************************************
Private global variables and functions
******************************************************************************/
static char firstTime = 1;	// use only in this file
int delay(void);
/******************************************************************************
* Function Name: intp_init
* Description  : Initialize INTP8 (SW2), INTP9 (SW3) and INTP10 (SW1) interrupt
* Arguments    : none
* Return Value : none
******************************************************************************/
void intp_init(void)
{
	/* Disable INTP8 operation */
    	PMK8 = 1U;
	/* Disable INTP9 operation */
    	PMK9 = 1U;
	/* Disable INTP10 operation */
    	PMK10 = 1U;

	/* Clear INTP8 interrupt flag */
    	PIF8 = 0U;
	/* Clear INTP9 interrupt flag */
    	PIF9 = 0U;
	/* Clear INTP10 interrupt flag */
    	PIF10 = 0U;

	/* Set INTP8 level 3 priority */
	PPR18 = 1U;
	PPR08 = 1U;

	/* Set INTP9 level 3 priority */
	PPR19 = 1U;
	PPR09 = 1U;

	/* Set INTP10 level 3 priority */
	PPR110 = 1U;
	PPR010 = 1U;

	/* Set INTP8, INTP9 and INTP10 falling edge detection */
	EGN1 |= 0x07U;

	/* Set INTP8 port pin as input - PM74 */
	PM7_bit.no4 = 1;
	/* Set INTP9 port pin as input - PM75 */
	PM7_bit.no5 = 1;
	/* Set INTP10 port pin as input - PM76 */
	PM7_bit.no6 = 1;

	/* Enable INTP8 interrupt */
	PMK8 = 0U;
	/* Enable INTP9 interrupt */
	PMK9 = 0U;
	/* Enable INTP10 interrupt */
	PMK10 = 0U;
}

/******************************************************************************
* Function Name: intp8_isr
* Description  : Interrupt service routine for INTP8 (SW2)
		 SW2 is used to set the minute that varies from 0 to 59.
		 When it is pressed, the minute is incremented by 1.
		 
		 While the timer is in pausing state:
		 If SW2 is pressed, the timer will be reset (e.g. 00:00)
		 
* Arguments    : none
* Return Value : none
******************************************************************************/
__interrupt void intp8_isr(void)
{
	//unsigned int LuiCount = 3200;
	
	//while(LuiCount--);	/* wait */
	
	/* Enable interrupt */
	//EI();
	
	if((P7&0x10) == 0x00)
	{		
		
		SW2_flag = 1;
	}
	
	/* Clear interrupt flag */
	PIF8 = 0;
}

/******************************************************************************
* Function Name: intp9_isr
* Description  : Interrupt service routine for INTP9 (SW3)
		 SW3 is used to:
		 - Start 
		 - Pause 
		 - 
* Arguments    : none
* Return Value : none
******************************************************************************/
__interrupt void intp9_isr(void)
{
    	unsigned int LuiCount = 3200;

    	while(LuiCount--);	/* wait */
	
	/* Enable interrupt */
	//EI();
	
	
	if((P7&0x20) == 0x00)
	{
		/* Switch to next mode */
		
	}
	
	/* Clear interrupt flag */
	PIF9 = 0;
}

/******************************************************************************
* Function Name: intp10_isr
* Description  : Interrupt service routine for INTP10 (SW1)
		 SW1 is used to set the second that varies from 0 to 59.
		 When it is pressed, the second is incremented by 1.
* Arguments    : none
* Return Value : none
******************************************************************************/
__interrupt void intp10_isr(void)
{
	//unsigned int LuiCount = 3200;
	
	//while(LuiCount--);	/* wait */
	
	/* Enable interrupt */
	//EI();
	
	if((P7&0x40) == 0x00)
	{
		SW1_flag = 1;	// Set flag
	}
	
	///* Clear interrupt flag */
	PIF10 = 0;
}


/******************************************************************************
* Function Name: chattering
* Description  : User use this to chattering when press button
* Arguments    : none
* Return Value : none
******************************************************************************/
static int output = 0x70;
static char previous = 0x70;	// default start value
static char current = 0;
static char match_time;
static int prevoutput = 0x70;
int chattering(void)
{
	prevoutput = output;
	current = (P7&0x70);
	if(previous!=current)
	{
		match_time=0;
		previous=current;
	}
	else{
		match_time=match_time+1;
		if(match_time>50)
		{
			match_time=0;
			output=current;
			if(output==0x20&&prevoutput!=0x20)
				prevoutput=0x70;
		}
	}
  	return (output ^ prevoutput) & (~output);
}
/******************************************************************************
End of file
******************************************************************************/

