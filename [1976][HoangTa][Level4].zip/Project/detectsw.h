
#include "r_macro.h"  /* System macro and standard type definition */


#define SW3	(0x50)
#define PRESS (P7&0x70)


/******************************************************************************
* Function Name: getswitch
* Description  : check Switch and reduce chattering
* Arguments    : none
* Return Value : none
******************************************************************************/

unsigned int getswitch();



/******************************************************************************
* Function Name: delay
* Description  : delay for reduce noise 
* Arguments    : none
* Return Value : none
******************************************************************************/
void delay();