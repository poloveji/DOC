#include "r_macro.h"
#include "led.h"
/******************************************************************************
* Function Name: initLED
* Description  : Configure for all LEDs
* Arguments    : none
* Return Value : none
******************************************************************************/
void initLED()
{
	// Set output mode port 4,6,10,15
	PM4 &= ~0x3c;
	PM6 &= ~0xfc;	// reduce warning W0401: Conversion may lose significant digits
	PM10 &= ~0x02;
	PM15 &= ~0x04;
	PM1_bit.no0 = 0;	// LED2 on-board
	PM4_bit.no1 = 0;	// LED15 on-board
	ADPC = 1;	// P15.2 digital mode
	// Turn off all LEDs
	TurnOffLED();
}

/******************************************************************************
* Function Name: TurnOffLED
* Description  : Turn off all LEDs
* Arguments    : none
* Return Value : none
******************************************************************************/
void TurnOffLED()
{
	P4 |= 0x3c;
	P6 |= 0xfc;
	P10 |= 0x02;
	P15 |= 0x04;

	P4_bit.no1 = 1;		// LED15 on-board
		
	P1_bit.no0 = 0;		// LED2 on-board
}

/******************************************************************************
* Function Name: TurnOnLED
* Description  : Turn on all LEDs
* Arguments    : none
* Return Value : none
******************************************************************************/
void TurnOnLED()
{
	P4 &= ~0x3c;	
 	P6 &= ~0xfc;  //// reduce warning W0401: Conversion may lose significant digits
	P10 &= ~0x02;
	P15 &= ~0x04;
	
	P4_bit.no1 = 0;		// LED15 on-board
		
	P1_bit.no0 = 1;		// LED2 on-board
}

/******************************************************************************
* Function Name: GetLEDStatus
* Description  : Return status of LED3 -> LED15
* Arguments    : none
* Return Value : LED on, bit = 1
		 LED off, bit = 0	
******************************************************************************/
uint16_t GetLEDStatus(void)
{
	uint16_t stt = 0x0000;
	
	stt |= P6_bit.no2 == 0 ? 0x0001 : 0x0000;	// LED3
	stt |= P4_bit.no2 == 0 ? 0x0002 : 0x0000;	// LED4
	stt |= P6_bit.no3 == 0 ? 0x0004 : 0x0000;	// LED5
	stt |= P4_bit.no3 == 0 ? 0x0008 : 0x0000;	// LED6
	
	stt |= P6_bit.no4 == 0 ? 0x0010 : 0x0000;	// LED7
	stt |= P4_bit.no4 == 0 ? 0x0020 : 0x0000;	// LED8
	stt |= P6_bit.no5 == 0 ? 0x0040 : 0x0000;	// LED9
	stt |= P4_bit.no5 == 0 ? 0x0080 : 0x0000;	// LED10

	stt |= P6_bit.no6 == 0  ? 0x0100 : 0x0000;	// LED11
	stt |= P15_bit.no2 == 0 ? 0x0200 : 0x0000;	// LED12
	stt |= P6_bit.no7 == 0  ? 0x0400 : 0x0000;	// LED13
	stt |= P10_bit.no1 == 0 ? 0x0800 : 0x0000;	// LED14
	
	stt |= P4_bit.no1 == 0  ? 0x1000 : 0x0000;	// LED15	
	
	return stt;
	
}

/******************************************************************************
* Function Name: ControlLED
* Description  : Status of LEDs
* Arguments    : none
* Return Value : LED on, bit = 1
		 LED off, bit = 0	 	
******************************************************************************/
void ControlLED(uint16_t stt)
{
	stt = ~stt;	// 0xE000 - 0xFFFF	
	
	P6_bit.no2 = (stt & 0x0001);			// LED3
	P4_bit.no2 = (stt & 0x0002) >> 1;		// LED4
	P6_bit.no3 = (stt & 0x0004) >> 2;		// LED5
	P4_bit.no3 = (stt & 0x0008) >> 3;		// LED6
	
	P6_bit.no4 = (stt & 0x0010) >> 4;		// LED7
	P4_bit.no4 = (stt & 0x0020) >> 5;		// LED8
	P6_bit.no5 = (stt & 0x0040) >> 6;		// LED9
	P4_bit.no5 = (stt & 0x0080) >> 7;		// LED10
	
	P6_bit.no6  = (stt & 0x0100) >> 8;		// LED11
	P15_bit.no2 = (stt & 0x0200) >> 9;		// LED12
	P6_bit.no7  = (stt & 0x0400) >> 10;		// LED13
	P10_bit.no1 = (stt & 0x0800) >> 11;		// LED14
	
	P4_bit.no1 = (stt & 0x1000)  >> 12;		// LED15
	
}
