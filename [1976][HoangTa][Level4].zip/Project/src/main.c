/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized. This 
* software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING 
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT 
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE 
* AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR 
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE 
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software 
* and to discontinue the availability of this software.  By using this software, 
* you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2011, 2013 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : main.c
* Version      : 1.0.0
* Device(s)    : R5F104PJ
* Tool-Chain   : CA78K0R
* Description  : This file implements main function.
* Creation Date: 09-Sep-15
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_macro.h"
#include "r_spi_if.h"
#include "lcd.h"
#include "uart.h"
#include "adc.h"
#include "led.h"
#include "api.h"
#include <string.h>
#include "stdio.h"
//#include "sw.h"
#include "detectsw.h"
#include "intp.h"
/******************************************************************************
Typedef definitions
******************************************************************************/
#define MAXVOLTAGE 999	//3.30
#define RESOLUTION 1023
#define OVERALLERROR	   1.2
/******************************************************************************
Macro definitions
******************************************************************************/

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/

/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/


/******************************************************************************
Private global variables and functions
******************************************************************************/
void r_main_userinit(void);
float abs(float);
void printLCD(char **, uint8_t , uint8_t );
void ResetWDG(void);
void DisplayMessageError(void);



uint8_t snd_msg_flg = 0;
uint8_t rcv_msg_flg = 0;
char bufferLED[13] = "$1976,LHHHH^";		// example �$1234,L1003^� , "$1234,A500^"
char bufferAnalog[13] = "$1976,ADDD^";		//
char bufferLCD[8][19] = {0};//"1234567890","asdfqwer","123w3","111","123","qazwsx","12345678","123456"};//{0};
/* LEDs variables */
uint16_t LEDs_status = 0x0000;


/* Declare a variable for A/D results */
volatile uint16_t gADC_Result = 0;


float voltage = 0;
float prev_voltage = 0;
float diff = 0;
float sosanh;
uint8_t error_flag = NO_ERROR;

//switch
//uint8_t check = 0;

static uint8_t i;
/**********************************************************************
extern variable declare
******************************************************************/

extern unsigned char LCD_Line;
extern int num;
extern char temp_receive[UART_RX_BUFFER_LEN];
extern unsigned int check;
extern unsigned int enable_switch;

int index=0;
int lcd_status;
//int time_flag ;

volatile uint16_t cnt = 0x0001;

/***********************************************************************************************************************
* Function Name: main
* Description  : This function implements main function.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void main(void)
{
	r_main_userinit();
    
	/* Initialize external interrupt - SW */
	
	
	/* Initialize UART1 communication */
	Uart_Init();
	/* Initialize ADC module */
	ADC_Create();
	ADC_Set_OperationOn();	
	/* Initialize 12-bit interval timer */
	R_IT_Create();
	/*LED_init*/
	initLED();
	  
	/* Start UART1 communication */
	Uart_Start();
	/* Start an A/D conversion */
	ADC_Start(); 
	/* Enable 12-bit interval timer */
	R_IT_Start();
	

	/*enable check switch*/
	enable_switch =1;	
    
	/* Start external interrupt - SW */
    	//TurnOnLED();
	while (1U)
	{
		/*Check timer after 200ms*/
		if (snd_msg_flg == 1)
		{
			snd_msg_flg = 0;
			/*Start UART */
			Uart_Start();

			// Send LED message
			LEDs_status = GetLEDStatus();
			sprintf(bufferLED,"$1976,L%.4x^",LEDs_status);
			Uart_Transmit(bufferLED,12);
			
			// Send Analog message
			GetADCResult();			
			gADC_Result = ADCR >> 6U;
			voltage = ((float)gADC_Result*MAXVOLTAGE)/RESOLUTION;
			
			diff = abs(voltage - prev_voltage);	// conversion error
			if(diff > (OVERALLERROR * MAXVOLTAGE/RESOLUTION) )				
			{
				prev_voltage = voltage;
				sprintf(bufferAnalog,"$1976,A%.3d^",(uint16_t)voltage);
			}		
			Uart_Transmit(bufferAnalog,12);	    
			
					
		} 
		
		
		
		if(rcv_msg_flg == 1)
		{
			
			rcv_msg_flg = 0;
			if(rx_buff[1] == 'T')		// Text String message
			{
				char _rx_buff[UART_RX_BUFFER_LEN+1] = "$T,X,XXX^";
				char c_index[2]="  " ;					
				uint16_t i_index = 0;				// LCD line number
				char str[UART_RX_BUFFER_LEN - 6];		// string not longer than 19
				static uint16_t LCD_line = 0;
				
				
				strcpy(_rx_buff, rx_buff);			// copy UART buffer rx_buff
						
				c_index[0] = _rx_buff[3];	// Copy index				
				i_index = atoi(c_index) - 1;		// Convert string to integer	
				
				for(i = 5; _rx_buff[i] != '^' && (i-5)<(UART_RX_BUFFER_LEN - 6); i++)
				{
					str[i-5] = _rx_buff[i];
				}
				str[i] = '\0';
				Uart_ClearBuff(rx_buff,UART_RX_BUFFER_LEN+1);		// Clear UART buffer
				Uart_ClearBuff(_rx_buff,UART_RX_BUFFER_LEN+1);		// Clear UART buffer copy
				
				LCD_line = i_index;
				Uart_ClearBuff(bufferLCD[i_index],UART_RX_BUFFER_LEN - 6);	// Clear LCD buffer
				
				strcpy(bufferLCD[i_index], str);	
				Uart_ClearBuff(str,UART_RX_BUFFER_LEN - 6);		
				
				DisplayLCD((uint8_t)(LCD_LINE1 + i_index*8),(uint8_t*)(bufferLCD+i_index));
				
				
				LCD_line++;
				if(LCD_line > 8) 
				{
					LCD_line = 0;
					for(i = 0; i < 8; i++)
					{
						Uart_ClearBuff(bufferLCD[i],UART_RX_BUFFER_LEN - 6);	// Clear LCD buffer
					}
				}
				
				// Print LCD
//				for(i = 0; i < 8; i++)
//				{
//					DisplayLCD(LCD_LINE1 + i*8,(uint8_t*)(bufferLCD+i));
//				
//				}
			}
			else if(rx_buff[1] == 'L')	// LEDs message  "$L,15,1^"  ////////////check ERROR of UART
			{
				char c_index[2] = "  ";
				char c_LED_stt; 
				uint16_t i_index = 0, i_LED_stt = 0;
				uint16_t mask = 0x0001;
				
				for(i = 3; rx_buff[i] != ',' ; i++)
				{
					c_index[i-3] = rx_buff[i];	// Copy index
				}		
		
				i_index = atoi(c_index) - 3;		// Convert string to integer
				c_LED_stt = rx_buff[i+1];		// index 5 or 6
				
				if(c_LED_stt == '0')				// LED off
				{
					LEDs_status &= ~(mask << i_index);
				}
				else if(c_LED_stt == '1')			// LED on
				{
					LEDs_status |= (mask << i_index);
				}
	
				ControlLED(LEDs_status);
				
			}
			else
			{
				;//ERROR
			}
		}
		
	}
}


/******************************************************************************
* Function Name: r_main_userinit
* Description  : User initialization routine
* Arguments    : none
* Return Value : none
******************************************************************************/
void r_main_userinit(void)
{
	uint16_t i;

	/* Enable interrupt */
	EI();

	/* Output a logic LOW level to external reset pin*/
	P13_bit.no0 = 0;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Generate a raising edge by ouput HIGH logic level to external reset pin */
	P13_bit.no0 = 1;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Output a logic LOW level to external reset pin, the reset is completed */
	P13_bit.no0 = 0;
	
	/* Initialize SPI channel used for LCD */
	R_SPI_Init(SPI_LCD_CHANNEL);
	
	/* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
	R_SPI_SslInit(
		SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
		(unsigned char *)&P14,   /* Select Port register */
		(unsigned char *)&PM14,  /* Select Port mode register */
		5,                       /* Select pin index in the port */
		0,                       /* Configure CS pin active state, 0 means active LOW level  */
		0                        /* Configure CS pin active mode, 0 means active per transfer */
	);
	
	/* Initialize LCD driver */
	InitialiseLCD();
	
	/* Clear LCD display */
	ClearLCD();	
}


float abs(float val)
{
	return val>0 ? val : -val;
}

void printLCD(char **buffer, uint8_t max_line, uint8_t max_row)
{
	static uint8_t i;
	ClearLCD();
	for(i = 0; i < max_line; i++)
	{
		DisplayLCD(LCD_LINE1 + i*8,(uint8_t*)(buffer+i));
	}
}

/***********************************************************************************************************************
* Function Name: DisplayMessageError
* Description  : display "Msg Err" on LCD
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void DisplayMessageError(void)
{
	error_flag = MSG_ERROR;
	ClearLCD();	
	DisplayLCD(LCD_LINE8, (uint8_t *)"Msg Err");	
	P1_bit.no0 = 1;		/*turn on led 2*/
	SIR03 = 0x07;    	/*clear flag trigger */
}

/***********************************************************************************************************************
* Function Name: DisplayUARTError
* Description  : display "Msg Err" on LCD
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void DisplayUARTError(void)
{
	error_flag = MSG_ERROR;
	ClearLCD();	
	DisplayLCD(LCD_LINE8, (uint8_t *)"UART Err");	
	P1_bit.no0 = 1;		/*turn on led 2*/
	SIR03 = 0x07;     	/*clear flag trigger */
}

/******************************************************************************
End of file
******************************************************************************/
